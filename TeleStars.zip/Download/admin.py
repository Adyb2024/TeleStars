# ════════════════════════════════════════════════════════════════
#  admin.py  —  نظام التحكم الإداري المتقدم
#  يُسجَّل في main.py عبر admin.register_admin_handlers(app)
# ════════════════════════════════════════════════════════════════

from __future__ import annotations

import asyncio
import csv
import io
import logging
from datetime import datetime, timezone
from typing import Any

from telegram import InputFile, Update
from telegram.constants import ParseMode
from telegram.error import TelegramError
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
)

import config
import db
import ton_utils
from keyboards import (
    admin_cancel_conv_keyboard,
    admin_panel_v2_keyboard,
    admin_report_actions_keyboard,
    admin_reports_keyboard,
    admin_settings_keyboard,
    admin_today_tx_keyboard,
    admin_user_mgmt_keyboard,
    back_to_main_keyboard,
)

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────
# حالات ConversationHandler
# ─────────────────────────────────────────────────────────────

(
    ADM_SEARCH,
    ADM_BAN,
    ADM_UNBAN,
    ADM_CHANNEL,
    ADM_SELL_PRICE,
    ADM_MIN_STARS,
    ADM_LOW_BAL,
) = range(20, 27)


# ─────────────────────────────────────────────────────────────
# مساعدات داخلية
# ─────────────────────────────────────────────────────────────

def _is_admin(user_id: int) -> bool:
    return user_id in config.ADMIN_USER_IDS


async def _guard(update: Update) -> bool:
    """يُعيد False ويرسل تنبيهاً إذا لم يكن المستخدم مسؤولاً."""
    if not _is_admin(update.effective_user.id):
        if update.callback_query:
            await update.callback_query.answer("⛔ ليس لديك صلاحية.", show_alert=True)
        return False
    return True


def _get_setting(key: str, default: str) -> str:
    return db.get_setting(key) or default


STATUS_EMOJI = {
    "pending": "⏳", "invoice_sent": "📤",
    "paid": "💳", "completed": "✅", "failed": "❌",
}


def _fmt_tx_block(tx) -> str:
    """تنسيق معاملة واحدة كنص HTML مضغوط."""
    emoji    = STATUS_EMOJI.get(tx["status"], "❓")
    username = tx["username"] if tx["username"] else tx.get("first_name", "N/A")
    return (
        f"{emoji} <code>{tx['unique_id']}</code>\n"
        f"   👤 @{username} | ⭐ {tx['star_count']:,} | 💎 {tx['ton_amount']:.4f}\n"
        f"   📅 {str(tx['created_at'])[:16]}"
    )


def _now() -> str:
    return datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


# ════════════════════════════════════════════════════════════════
#  1. لوحة التحكم الرئيسية (تستبدل الإصدار القديم)
# ════════════════════════════════════════════════════════════════

async def cb_admin_panel_v2(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """عرض لوحة التحكم الإدارية الشاملة."""
    if not await _guard(update):
        return

    query  = update.callback_query or update.message
    active = context.bot_data.get("is_active", True)
    price  = context.bot_data.get("ton_usd_price", 0.0)
    status = "🟢 مفعّل" if active else "🔴 متوقف"

    text = (
        f"⚙️ <b>لوحة التحكم الإدارية</b>\n"
        f"{'─' * 32}\n"
        f"حالة البوت: {status}\n"
        f"سعر TON:   <b>${price:.3f}</b>\n"
        f"🕐 {_now()}"
    )

    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(
            text, parse_mode=ParseMode.HTML, reply_markup=admin_panel_v2_keyboard()
        )
    else:
        await update.message.reply_text(
            text, parse_mode=ParseMode.HTML, reply_markup=admin_panel_v2_keyboard()
        )


# ════════════════════════════════════════════════════════════════
#  2. لوحة معلومات سريعة (Dashboard)
# ════════════════════════════════════════════════════════════════

async def cb_admin_dashboard(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """لوحة بيانات آنية: رصيد TON، سعر، إحصائيات."""
    if not await _guard(update):
        return

    query = update.callback_query
    await query.answer("⏳ جارٍ جلب البيانات...")

    stats     = db.get_transaction_stats()
    ton_price = context.bot_data.get("ton_usd_price", 0.0)

    try:
        ton_balance = ton_utils.get_bot_ton_balance()
        bal_txt     = f"<b>{ton_balance:.4f} TON</b>"
    except Exception:
        bal_txt = "<i>تعذّر الجلب</i>"

    low_threshold = float(_get_setting("low_balance_threshold", "10"))
    low_warn      = (
        "\n⚠️ <b>تحذير: الرصيد منخفض!</b>" if ton_balance < low_threshold else ""  # type: ignore[operator]
    )

    # نجوم البوت عبر getStarTransactions — مبسّط
    stars_info = "<i>غير متاح مباشرة</i>"
    try:
        result = await context.bot.get_star_transactions(limit=1)
        stars_info = f"<b>{result.transactions[0].amount if result.transactions else 'N/A'}</b>"
    except Exception:
        pass

    text = (
        f"📊 <b>لوحة المعلومات الفورية</b>\n"
        f"{'━' * 30}\n"
        f"💰 رصيد TON:           {bal_txt}{low_warn}\n"
        f"📈 سعر TON/USD:        <b>${ton_price:.4f}</b>\n"
        f"{'─' * 30}\n"
        f"👥 المستخدمون:          <b>{stats['user_count']}</b>\n"
        f"📋 إجمالي المعاملات:    <b>{stats['total']}</b>\n"
        f"   ✅ مكتملة:            <b>{stats['completed']}</b>\n"
        f"   ⏳ معلّقة:            <b>{stats['pending']}</b>\n"
        f"   ❌ فاشلة:             <b>{stats['failed']}</b>\n"
        f"{'─' * 30}\n"
        f"⭐ نجوم مشتراة:        <b>{stats['total_stars_bought']:,}</b>\n"
        f"💎 TON مدفوعة:         <b>{stats['total_ton_paid']:.4f}</b>\n"
        f"{'─' * 30}\n"
        f"🕐 {_now()}"
    )

    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 تحديث", callback_data="adm_dashboard")],
        [InlineKeyboardButton("◀️ رجوع",  callback_data="admin_panel")],
    ])
    await query.edit_message_text(
        text, parse_mode=ParseMode.HTML, reply_markup=keyboard
    )


# ════════════════════════════════════════════════════════════════
#  3. معاملات اليوم (مع pagination)
# ════════════════════════════════════════════════════════════════

async def cb_admin_today_tx(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """عرض معاملات اليوم الحالي مقسّمة بصفحات."""
    if not await _guard(update):
        return

    query    = update.callback_query
    await query.answer()
    page     = int(query.data.split(":")[1])
    per_page = 5

    txs, total = db.get_today_transactions(page, per_page)
    total_pages = max(1, (total + per_page - 1) // per_page)

    if not txs and page == 0:
        text = "📋 <b>معاملات اليوم</b>\n\nلا توجد معاملات حتى الآن اليوم."
    else:
        lines = [f"📋 <b>معاملات اليوم</b>  ({total} معاملة) — صفحة {page+1}/{total_pages}\n{'─'*30}"]
        for tx in txs:
            lines.append("\n" + _fmt_tx_block(tx))
        text = "\n".join(lines)

    await query.edit_message_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=admin_today_tx_keyboard(page, total_pages),
    )


# ════════════════════════════════════════════════════════════════
#  4. البحث عن معاملة — ConversationHandler
# ════════════════════════════════════════════════════════════════

async def cb_adm_search_entry(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await _guard(update):
        return ConversationHandler.END

    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        "🔍 <b>البحث عن معاملة</b>\n\n"
        "أرسل أحد التالي:\n"
        "• <code>@username</code> — اسم المستخدم\n"
        "• <b>معرف رقمي</b> (مثل: <code>123456789</code>)\n"
        "• <b>UUID معاملة</b> (مثل: <code>A1B2C3D4E5F6</code>)",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_cancel_conv_keyboard(),
    )
    return ADM_SEARCH


async def handle_search_input(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """معالجة مدخل البحث وعرض النتائج."""
    raw   = update.message.text.strip()
    lines: list[str] = []

    # البحث بـ UUID: حروف وأرقام بدون @ و12 حرفاً
    if len(raw) == 12 and raw.replace("-", "").isalnum():
        tx = db.search_transaction_by_uuid(raw)
        results = [tx] if tx else []
        header  = f"🔍 نتيجة البحث عن UUID: <code>{raw}</code>"

    # البحث برقم ID
    elif raw.lstrip("-").isdigit():
        results = db.search_transactions_by_user_id(int(raw))
        header  = f"🔍 نتائج البحث للمستخدم ID: <code>{raw}</code>"

    # البحث بـ username
    else:
        results = db.search_transactions_by_username(raw)
        header  = f"🔍 نتائج البحث عن: <code>{raw}</code>"

    if not results:
        await update.message.reply_text(
            f"❌ <b>لا توجد نتائج</b> للبحث: <code>{raw}</code>",
            parse_mode=ParseMode.HTML,
            reply_markup=admin_panel_v2_keyboard(),
        )
        return ConversationHandler.END

    lines.append(f"{header}\n{'─' * 30}\n<b>({len(results)} نتيجة)</b>")
    for tx in results[:10]:
        lines.append("\n" + _fmt_tx_block(tx))
        if tx["status"] == "completed" and tx["ton_tx_hash"]:
            lines.append(f"   🔗 <code>{tx['ton_tx_hash']}</code>")
        if tx["wallet_address"]:
            lines.append(f"   🏦 <code>{tx['wallet_address']}</code>")

    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
    await update.message.reply_text(
        "\n".join(lines),
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("◀️ رجوع للوحة التحكم", callback_data="admin_panel")]
        ]),
    )
    return ConversationHandler.END


# ════════════════════════════════════════════════════════════════
#  5. التقارير
# ════════════════════════════════════════════════════════════════

async def cb_admin_reports_menu(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await _guard(update):
        return
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        "📈 <b>التقارير</b>\n\nاختر الفترة الزمنية:",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_reports_keyboard(),
    )


async def cb_admin_report(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """عرض تقرير الفترة المحددة."""
    if not await _guard(update):
        return

    query = update.callback_query
    await query.answer("⏳ جارٍ إنشاء التقرير...")

    days    = int(query.data.split(":")[1])
    data    = db.get_report_data(days)
    sellers = db.get_top_sellers(days, limit=5)

    sell_price = float(_get_setting("sell_price_per_100", "1.50"))
    buy_price  = float(config.PRICE_PER_100_STARS_USD)
    profit_est = (data["total_stars"] / 100) * (sell_price - buy_price)

    period_labels = {1: "آخر 24 ساعة", 7: "آخر 7 أيام", 14: "آخر 14 يوماً", 30: "آخر 30 يوماً"}
    period = period_labels.get(days, f"آخر {days} يوم")

    sellers_txt = ""
    if sellers:
        sellers_txt = f"\n{'─' * 30}\n🏆 <b>أكثر 5 مستخدمين مبيعاً:</b>\n"
        for i, s in enumerate(sellers, 1):
            uname = f"@{s['username']}" if s["username"] else s["first_name"] or "N/A"
            sellers_txt += f"   {i}. {uname} — <b>{s['total_stars']:,} ⭐</b>\n"

    text = (
        f"📊 <b>تقرير: {period}</b>\n"
        f"{'━' * 30}\n"
        f"📋 إجمالي المعاملات:   <b>{data['total_tx']}</b>\n"
        f"✅ المكتملة:           <b>{data['completed']}</b>\n"
        f"{'─' * 30}\n"
        f"⭐ نجوم مشتراة:       <b>{data['total_stars']:,}</b>\n"
        f"💎 TON مدفوعة:        <b>{data['total_ton']:.4f}</b>\n"
        f"💵 قيمة USD:          <b>${data['total_usd']:.2f}</b>\n"
        f"{'─' * 30}\n"
        f"💰 <b>الربح التقديري:</b>\n"
        f"   سعر البيع الافتراضي: <b>${sell_price}</b>/100⭐\n"
        f"   سعر الشراء الفعلي:  <b>${buy_price}</b>/100⭐\n"
        f"   الربح التقديري:     <b>${profit_est:.2f}</b>"
        f"{sellers_txt}\n"
        f"{'━' * 30}\n"
        f"🕐 {_now()}"
    )

    await query.edit_message_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=admin_report_actions_keyboard(days),
    )


async def cb_admin_export_csv(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """تصدير معاملات الفترة كملف CSV وإرساله للمسؤول."""
    if not await _guard(update):
        return

    query = update.callback_query
    await query.answer("⏳ جارٍ إنشاء ملف CSV...")

    days = int(query.data.split(":")[1])
    rows = db.get_transactions_for_export(days)

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow([
        "unique_id", "username", "first_name", "user_id",
        "star_count", "ton_amount", "usd_amount",
        "wallet_address", "status", "ton_tx_hash", "created_at"
    ])
    for r in rows:
        writer.writerow([
            r["unique_id"],
            r["username"] or "",
            r["first_name"] or "",
            r["user_id"],
            r["star_count"],
            r["ton_amount"],
            r["usd_amount"],
            r["wallet_address"],
            r["status"],
            r["ton_tx_hash"] or "",
            r["created_at"],
        ])

    buf.seek(0)
    filename = f"report_{days}d_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"

    await context.bot.send_document(
        chat_id=update.effective_user.id,
        document=InputFile(io.BytesIO(buf.getvalue().encode("utf-8-sig")), filename=filename),
        caption=f"📤 تقرير آخر {days} يوم — {len(rows)} معاملة\n🕐 {_now()}",
    )


# ════════════════════════════════════════════════════════════════
#  6. إدارة المستخدمين
# ════════════════════════════════════════════════════════════════

async def cb_admin_user_mgmt(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await _guard(update):
        return
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        "👥 <b>إدارة المستخدمين</b>\n\nاختر الإجراء:",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_user_mgmt_keyboard(),
    )


async def cb_admin_banned_list(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await _guard(update):
        return
    query   = update.callback_query
    await query.answer()
    banned  = db.get_banned_users()

    if not banned:
        text = "✅ <b>لا يوجد مستخدمون محظورون حالياً.</b>"
    else:
        lines = [f"🚫 <b>المستخدمون المحظورون ({len(banned)})</b>\n{'─' * 28}"]
        for u in banned:
            uname = f"@{u['username']}" if u["username"] else u["first_name"] or "N/A"
            lines.append(f"• {uname} — <code>{u['user_id']}</code>")
        text = "\n".join(lines)

    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
    await query.edit_message_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("◀️ رجوع", callback_data="adm_user_mgmt")]
        ]),
    )


# ── حظر مستخدم ────────────────────────────────────────────────

async def cb_adm_ban_entry(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await _guard(update):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        "🚫 <b>حظر مستخدم</b>\n\n"
        "أرسل <b>username</b> (مع أو بدون @) أو <b>معرف رقمي</b>:",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_cancel_conv_keyboard(),
    )
    return ADM_BAN


async def handle_ban_input(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    raw = update.message.text.strip()
    user_id, username = _resolve_user(raw)

    if user_id is None:
        await update.message.reply_text(
            "❌ لم يُعثر على هذا المستخدم في قاعدة البيانات.",
            reply_markup=admin_panel_v2_keyboard(),
        )
        return ConversationHandler.END

    success = db.ban_user(user_id)
    uname_display = f"@{username}" if username else str(user_id)

    if success:
        await update.message.reply_text(
            f"✅ <b>تم حظر المستخدم:</b> {uname_display}\n"
            f"ID: <code>{user_id}</code>",
            parse_mode=ParseMode.HTML,
            reply_markup=admin_user_mgmt_keyboard(),
        )
    else:
        await update.message.reply_text(
            f"⚠️ المستخدم {uname_display} غير موجود في قاعدة البيانات.",
            reply_markup=admin_user_mgmt_keyboard(),
        )
    return ConversationHandler.END


# ── فك الحظر ──────────────────────────────────────────────────

async def cb_adm_unban_entry(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await _guard(update):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        "✅ <b>فك حظر مستخدم</b>\n\n"
        "أرسل <b>username</b> أو <b>معرف رقمي</b>:",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_cancel_conv_keyboard(),
    )
    return ADM_UNBAN


async def handle_unban_input(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    raw = update.message.text.strip()
    user_id, username = _resolve_user(raw)

    if user_id is None:
        await update.message.reply_text(
            "❌ لم يُعثر على هذا المستخدم.",
            reply_markup=admin_user_mgmt_keyboard(),
        )
        return ConversationHandler.END

    success = db.unban_user(user_id)
    uname_display = f"@{username}" if username else str(user_id)

    if success:
        await update.message.reply_text(
            f"✅ <b>تم فك حظر المستخدم:</b> {uname_display}",
            parse_mode=ParseMode.HTML,
            reply_markup=admin_user_mgmt_keyboard(),
        )
    else:
        await update.message.reply_text(
            f"⚠️ المستخدم {uname_display} غير موجود أو لم يكن محظوراً.",
            reply_markup=admin_user_mgmt_keyboard(),
        )
    return ConversationHandler.END


def _resolve_user(raw: str) -> tuple[int | None, str | None]:
    """
    تحويل مدخل نصي (username أو ID) إلى (user_id, username).
    يُعيد (None, None) إذا لم يُعثر على المستخدم.
    """
    raw = raw.lstrip("@").strip()
    if raw.isdigit():
        user_id = int(raw)
        db_user = db.get_user(user_id)
        return (user_id, db_user["username"] if db_user else None) if db_user else (user_id, None)
    else:
        db_user = db.get_user_by_username(raw)
        if db_user:
            return db_user["user_id"], db_user["username"]
        return None, None


# ════════════════════════════════════════════════════════════════
#  7. الإعدادات المتقدمة
# ════════════════════════════════════════════════════════════════

async def cb_admin_settings(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await _guard(update):
        return
    query = update.callback_query
    await query.answer()

    sell_price    = _get_setting("sell_price_per_100", "1.50")
    channel       = _get_setting("notification_channel", getattr(config, "NOTIFICATION_CHANNEL", "غير محدد"))
    min_stars     = _get_setting("min_stars_override", str(config.MIN_STARS))
    low_bal       = _get_setting("low_balance_threshold", "10")
    daily_enabled = _get_setting("daily_report_enabled", "0") == "1"
    daily_lbl     = "✅ مفعّل" if daily_enabled else "❌ معطّل"

    text = (
        f"🛠 <b>الإعدادات المتقدمة</b>\n"
        f"{'─' * 30}\n"
        f"💵 سعر البيع التقديري: <b>${sell_price}/100⭐</b>\n"
        f"📢 قناة الإشعارات:     <b>{channel}</b>\n"
        f"⭐ الحد الأدنى للنجوم: <b>{min_stars}</b>\n"
        f"⚠️ حد منخفض TON:      <b>{low_bal} TON</b>\n"
        f"📅 تقرير يومي تلقائي:  {daily_lbl}"
    )
    await query.edit_message_text(
        text, parse_mode=ParseMode.HTML, reply_markup=admin_settings_keyboard()
    )


# ── تغيير سعر البيع التقديري ──────────────────────────────────

async def cb_adm_set_sell_price_entry(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await _guard(update):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    current = _get_setting("sell_price_per_100", "1.50")
    await query.edit_message_text(
        f"💵 <b>تغيير سعر البيع التقديري</b>\n\n"
        f"القيمة الحالية: <b>${current}</b> لكل 100 نجمة\n\n"
        f"أرسل السعر الجديد (مثال: <code>1.75</code>):",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_cancel_conv_keyboard(),
    )
    return ADM_SELL_PRICE


async def handle_sell_price_input(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    raw = update.message.text.strip().replace(",", ".")
    try:
        price = float(raw)
        if not (0.01 <= price <= 100):
            raise ValueError
    except ValueError:
        await update.message.reply_text(
            "❌ يرجى إدخال رقم صحيح بين 0.01 و 100.",
            reply_markup=admin_cancel_conv_keyboard(),
        )
        return ADM_SELL_PRICE

    db.set_setting("sell_price_per_100", str(price))
    await update.message.reply_text(
        f"✅ <b>تم تحديث سعر البيع التقديري إلى ${price:.2f}/100⭐</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_settings_keyboard(),
    )
    return ConversationHandler.END


# ── تغيير قناة الإشعارات ──────────────────────────────────────

async def cb_adm_set_channel_entry(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await _guard(update):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    current = _get_setting("notification_channel", getattr(config, "NOTIFICATION_CHANNEL", ""))
    await query.edit_message_text(
        f"📢 <b>تغيير قناة الإشعارات</b>\n\n"
        f"القناة الحالية: <code>{current}</code>\n\n"
        f"أرسل معرف القناة الجديد:\n"
        f"• بالـ @: <code>@MyChannel</code>\n"
        f"• أو ID رقمي: <code>-1001234567890</code>\n"
        f"• أرسل <code>0</code> لتعطيل الإشعارات",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_cancel_conv_keyboard(),
    )
    return ADM_CHANNEL


async def handle_channel_input(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    raw = update.message.text.strip()

    if raw == "0":
        db.set_setting("notification_channel", "")
        # تحديث config.py ديناميكياً
        config.NOTIFICATION_CHANNEL = ""  # type: ignore[attr-defined]
        await update.message.reply_text(
            "✅ <b>تم تعطيل إشعارات القناة.</b>",
            parse_mode=ParseMode.HTML,
            reply_markup=admin_settings_keyboard(),
        )
        return ConversationHandler.END

    if not (raw.startswith("@") or raw.lstrip("-").isdigit()):
        await update.message.reply_text(
            "❌ صيغة غير صحيحة. يجب أن يبدأ بـ @ أو يكون رقماً.",
            reply_markup=admin_cancel_conv_keyboard(),
        )
        return ADM_CHANNEL

    # التحقق بمحاولة إرسال رسالة
    try:
        await context.bot.send_message(
            chat_id=raw,
            text="✅ <b>تحقق الاتصال بالقناة — بوت النجوم</b>",
            parse_mode=ParseMode.HTML,
        )
    except TelegramError as exc:
        await update.message.reply_text(
            f"❌ <b>فشل الاتصال بالقناة:</b> <code>{exc}</code>\n\n"
            "تأكد من أن البوت مشرف في القناة.",
            parse_mode=ParseMode.HTML,
            reply_markup=admin_cancel_conv_keyboard(),
        )
        return ADM_CHANNEL

    db.set_setting("notification_channel", raw)
    config.NOTIFICATION_CHANNEL = raw  # type: ignore[attr-defined]

    await update.message.reply_text(
        f"✅ <b>تم تحديث قناة الإشعارات إلى:</b> <code>{raw}</code>",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_settings_keyboard(),
    )
    return ConversationHandler.END


# ── تغيير الحد الأدنى للنجوم ──────────────────────────────────

async def cb_adm_set_min_stars_entry(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await _guard(update):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    current = _get_setting("min_stars_override", str(config.MIN_STARS))
    await query.edit_message_text(
        f"⭐ <b>تغيير الحد الأدنى للنجوم</b>\n\n"
        f"القيمة الحالية: <b>{current} نجمة</b>\n\n"
        f"أرسل الحد الأدنى الجديد (50 — 10000):",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_cancel_conv_keyboard(),
    )
    return ADM_MIN_STARS


async def handle_min_stars_input(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    raw = update.message.text.strip()
    try:
        val = int(raw)
        if not (10 <= val <= 10_000):
            raise ValueError
    except ValueError:
        await update.message.reply_text(
            "❌ يرجى إدخال رقم بين 10 و 10,000.",
            reply_markup=admin_cancel_conv_keyboard(),
        )
        return ADM_MIN_STARS

    db.set_setting("min_stars_override", str(val))
    config.MIN_STARS = val  # type: ignore[attr-defined]
    await update.message.reply_text(
        f"✅ <b>تم تحديث الحد الأدنى إلى {val:,} نجمة</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_settings_keyboard(),
    )
    return ConversationHandler.END


# ── حد رصيد TON المنخفض ───────────────────────────────────────

async def cb_adm_set_low_bal_entry(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    if not await _guard(update):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    current = _get_setting("low_balance_threshold", "10")
    await query.edit_message_text(
        f"⚠️ <b>حد الرصيد المنخفض</b>\n\n"
        f"الحد الحالي: <b>{current} TON</b>\n\n"
        f"عند نزول الرصيد تحت هذا الحد يتلقى المسؤول تنبيهاً.\n"
        f"أرسل القيمة الجديدة (بـ TON):",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_cancel_conv_keyboard(),
    )
    return ADM_LOW_BAL


async def handle_low_bal_input(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    raw = update.message.text.strip().replace(",", ".")
    try:
        val = float(raw)
        if val < 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text(
            "❌ يرجى إدخال رقم موجب.",
            reply_markup=admin_cancel_conv_keyboard(),
        )
        return ADM_LOW_BAL

    db.set_setting("low_balance_threshold", str(val))
    await update.message.reply_text(
        f"✅ <b>تم تحديث حد الرصيد المنخفض إلى {val:.2f} TON</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_settings_keyboard(),
    )
    return ConversationHandler.END


# ── التقرير اليومي التلقائي ────────────────────────────────────

async def cb_adm_toggle_daily_report(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    if not await _guard(update):
        return
    query = update.callback_query
    await query.answer()

    current = db.get_setting("daily_report_enabled", "0") == "1"
    new_val = "0" if current else "1"
    db.set_setting("daily_report_enabled", new_val)

    label = "✅ مفعّل" if new_val == "1" else "❌ معطّل"
    await query.answer(f"تقرير يومي: {label}", show_alert=True)

    # إعادة رسم صفحة الإعدادات
    await cb_admin_settings(update, context)


# ── إلغاء المحادثة الإدارية ────────────────────────────────────

async def cb_adm_cancel_conv(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    context.user_data.pop("adm_state", None)
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        "❌ تم الإلغاء.",
        reply_markup=admin_panel_v2_keyboard(),
    )
    return ConversationHandler.END


async def cb_adm_noop(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    await update.callback_query.answer()


# ════════════════════════════════════════════════════════════════
#  8. مهام JobQueue
# ════════════════════════════════════════════════════════════════

async def job_daily_report(context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    إرسال تقرير يومي تلقائي للمسؤولين إذا كان مفعّلاً.
    يُشغَّل كل 24 ساعة عبر JobQueue.
    """
    if db.get_setting("daily_report_enabled", "0") != "1":
        return

    data    = db.get_report_data(1)
    sellers = db.get_top_sellers(1, 5)

    sell_price = float(db.get_setting("sell_price_per_100", "1.50") or "1.50")
    buy_price  = float(config.PRICE_PER_100_STARS_USD)
    profit_est = (data["total_stars"] / 100) * (sell_price - buy_price)

    sellers_txt = ""
    if sellers:
        sellers_txt = "\n🏆 <b>أعلى مبيعين اليوم:</b>\n"
        for i, s in enumerate(sellers, 1):
            uname = f"@{s['username']}" if s["username"] else s["first_name"] or "N/A"
            sellers_txt += f"   {i}. {uname} — {s['total_stars']:,} ⭐\n"

    text = (
        f"📅 <b>التقرير اليومي التلقائي</b>\n"
        f"{'━' * 30}\n"
        f"📋 معاملات اليوم:    <b>{data['total_tx']}</b>\n"
        f"✅ مكتملة:           <b>{data['completed']}</b>\n"
        f"⭐ نجوم مشتراة:     <b>{data['total_stars']:,}</b>\n"
        f"💎 TON مدفوعة:      <b>{data['total_ton']:.4f}</b>\n"
        f"💵 USD:              <b>${data['total_usd']:.2f}</b>\n"
        f"💰 ربح تقديري:      <b>${profit_est:.2f}</b>"
        f"{sellers_txt}"
        f"{'━' * 30}\n"
        f"🕐 {_now()}"
    )

    for admin_id in config.ADMIN_USER_IDS:
        try:
            await context.bot.send_message(
                chat_id=admin_id,
                text=text,
                parse_mode=ParseMode.HTML,
            )
        except TelegramError as exc:
            logger.warning(f"فشل إرسال التقرير اليومي للمسؤول {admin_id}: {exc}")


async def job_low_balance_check(context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    فحص رصيد TON دورياً وإرسال تنبيه للمسؤول عند الانخفاض.
    يُشغَّل كل ساعة عبر JobQueue.
    """
    try:
        balance   = ton_utils.get_bot_ton_balance()
        threshold = float(db.get_setting("low_balance_threshold", "10") or "10")

        if balance < threshold:
            text = (
                f"⚠️ <b>تحذير: رصيد TON منخفض!</b>\n\n"
                f"الرصيد الحالي: <b>{balance:.4f} TON</b>\n"
                f"الحد المضبوط:  <b>{threshold:.2f} TON</b>\n\n"
                f"يرجى إيداع المزيد لضمان استمرار المدفوعات."
            )
            for admin_id in config.ADMIN_USER_IDS:
                try:
                    await context.bot.send_message(
                        chat_id=admin_id,
                        text=text,
                        parse_mode=ParseMode.HTML,
                    )
                except TelegramError:
                    pass
            logger.warning(f"تنبيه رصيد منخفض: {balance:.4f} TON < {threshold} TON")

    except Exception as exc:
        logger.error(f"job_low_balance_check: فشل فحص الرصيد: {exc}")


# ════════════════════════════════════════════════════════════════
#  تسجيل جميع Handlers (يُستدعى من main.py)
# ════════════════════════════════════════════════════════════════

def register_admin_handlers(app: Application) -> None:
    """
    تسجيل جميع handlers الإدارية في التطبيق.
    يجب استدعاء هذه الدالة قبل تسجيل admin_panel الموجود في main.py.
    """

    # ── ConversationHandler: البحث ─────────────────────────────
    search_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(cb_adm_search_entry, pattern="^adm_search$")],
        states={
            ADM_SEARCH: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_search_input),
                CallbackQueryHandler(cb_adm_cancel_conv, pattern="^adm_cancel_conv$"),
            ],
        },
        fallbacks=[
            CommandHandler("cancel", cb_adm_cancel_conv),
        ],
        name="adm_search_flow",
        persistent=False,
        conversation_timeout=300,
    )

    # ── ConversationHandler: حظر ───────────────────────────────
    ban_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(cb_adm_ban_entry, pattern="^adm_ban_entry$")],
        states={
            ADM_BAN: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_ban_input),
                CallbackQueryHandler(cb_adm_cancel_conv, pattern="^adm_cancel_conv$"),
            ],
        },
        fallbacks=[CommandHandler("cancel", cb_adm_cancel_conv)],
        name="adm_ban_flow",
        persistent=False,
        conversation_timeout=300,
    )

    # ── ConversationHandler: فك حظر ────────────────────────────
    unban_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(cb_adm_unban_entry, pattern="^adm_unban_entry$")],
        states={
            ADM_UNBAN: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_unban_input),
                CallbackQueryHandler(cb_adm_cancel_conv, pattern="^adm_cancel_conv$"),
            ],
        },
        fallbacks=[CommandHandler("cancel", cb_adm_cancel_conv)],
        name="adm_unban_flow",
        persistent=False,
        conversation_timeout=300,
    )

    # ── ConversationHandler: إعداد القناة ──────────────────────
    channel_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(cb_adm_set_channel_entry, pattern="^adm_set_channel$")],
        states={
            ADM_CHANNEL: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_channel_input),
                CallbackQueryHandler(cb_adm_cancel_conv, pattern="^adm_cancel_conv$"),
            ],
        },
        fallbacks=[CommandHandler("cancel", cb_adm_cancel_conv)],
        name="adm_channel_flow",
        persistent=False,
        conversation_timeout=300,
    )

    # ── ConversationHandler: سعر البيع ─────────────────────────
    price_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(cb_adm_set_sell_price_entry, pattern="^adm_set_sell_price$")],
        states={
            ADM_SELL_PRICE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_sell_price_input),
                CallbackQueryHandler(cb_adm_cancel_conv, pattern="^adm_cancel_conv$"),
            ],
        },
        fallbacks=[CommandHandler("cancel", cb_adm_cancel_conv)],
        name="adm_price_flow",
        persistent=False,
        conversation_timeout=300,
    )

    # ── ConversationHandler: الحد الأدنى للنجوم ────────────────
    minstars_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(cb_adm_set_min_stars_entry, pattern="^adm_set_min_stars$")],
        states={
            ADM_MIN_STARS: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_min_stars_input),
                CallbackQueryHandler(cb_adm_cancel_conv, pattern="^adm_cancel_conv$"),
            ],
        },
        fallbacks=[CommandHandler("cancel", cb_adm_cancel_conv)],
        name="adm_minstars_flow",
        persistent=False,
        conversation_timeout=300,
    )

    # ── ConversationHandler: حد رصيد TON ───────────────────────
    lowbal_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(cb_adm_set_low_bal_entry, pattern="^adm_set_low_bal$")],
        states={
            ADM_LOW_BAL: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_low_bal_input),
                CallbackQueryHandler(cb_adm_cancel_conv, pattern="^adm_cancel_conv$"),
            ],
        },
        fallbacks=[CommandHandler("cancel", cb_adm_cancel_conv)],
        name="adm_lowbal_flow",
        persistent=False,
        conversation_timeout=300,
    )

    # ── تسجيل ConversationHandlers ──────────────────────────────
    for conv in [
        search_conv, ban_conv, unban_conv,
        channel_conv, price_conv, minstars_conv, lowbal_conv,
    ]:
        app.add_handler(conv)

    # ── Callbacks بسيطة (تُستبدل admin_panel القديم بأولوية أعلى) ──
    app.add_handler(CallbackQueryHandler(cb_admin_panel_v2,          pattern="^admin_panel$"))
    app.add_handler(CallbackQueryHandler(cb_admin_dashboard,          pattern="^adm_dashboard$"))
    app.add_handler(CallbackQueryHandler(cb_admin_today_tx,           pattern=r"^adm_today_tx:\d+$"))
    app.add_handler(CallbackQueryHandler(cb_admin_reports_menu,       pattern="^adm_reports_menu$"))
    app.add_handler(CallbackQueryHandler(cb_admin_report,             pattern=r"^adm_report:\d+$"))
    app.add_handler(CallbackQueryHandler(cb_admin_export_csv,         pattern=r"^adm_export_csv:\d+$"))
    app.add_handler(CallbackQueryHandler(cb_admin_user_mgmt,          pattern="^adm_user_mgmt$"))
    app.add_handler(CallbackQueryHandler(cb_admin_banned_list,        pattern="^adm_banned_list$"))
    app.add_handler(CallbackQueryHandler(cb_admin_settings,           pattern="^adm_settings$"))
    app.add_handler(CallbackQueryHandler(cb_adm_toggle_daily_report,  pattern="^adm_toggle_daily_report$"))
    app.add_handler(CallbackQueryHandler(cb_adm_noop,                 pattern="^adm_noop$"))

    # ── مهام JobQueue ───────────────────────────────────────────
    app.job_queue.run_repeating(
        job_daily_report,
        interval=86_400,   # كل 24 ساعة
        first=3_600,       # يبدأ بعد ساعة من التشغيل
        name="daily_report",
    )
    app.job_queue.run_repeating(
        job_low_balance_check,
        interval=3_600,    # كل ساعة
        first=120,         # يبدأ بعد دقيقتين
        name="low_balance_check",
    )

    logger.info("✅ تم تسجيل handlers لوحة التحكم الإدارية المتقدمة.")
