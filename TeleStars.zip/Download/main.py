# ════════════════════════════════════════════════════════════════
#  main.py  —  بوت شراء نجوم تيليجرام (Stars Buyer Bot)
#  نقطة الدخول + جميع Handlers
# ════════════════════════════════════════════════════════════════

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from typing import Optional

from telegram import (
    BotCommand,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    LabeledPrice,
    Update,
)
from telegram.constants import ParseMode
from telegram.error import TelegramError
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    PreCheckoutQueryHandler,
    filters,
)

import config
import db
import admin as admin_module
import notifier
import ton_utils
from keyboards import (
    admin_panel_keyboard,
    admin_recent_tx_keyboard,
    admin_stats_keyboard,
    back_to_main_keyboard,
    broadcast_cancel_keyboard,
    cancel_keyboard,
    confirm_order_keyboard,
    main_menu_keyboard,
    pagination_keyboard,
    retry_transfer_keyboard,
    wallet_input_keyboard,
)

# ─────────────────────────────────────────────────────────────
# إعداد التسجيل
# ─────────────────────────────────────────────────────────────

logging.basicConfig(
    format="%(asctime)s | %(name)-20s | %(levelname)-8s | %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────
# حالات ConversationHandler
# ─────────────────────────────────────────────────────────────

(
    WAITING_FOR_STAR_COUNT,
    WAITING_FOR_WALLET,
    CONFIRM_ORDER,
    BROADCAST_MESSAGE,
) = range(4)

# ─────────────────────────────────────────────────────────────
# تقييد معدل الطلبات (Rate Limiting)
# ─────────────────────────────────────────────────────────────

_last_request: dict[int, float] = {}


def _is_rate_limited(user_id: int) -> bool:
    """يُعيد True إذا كان المستخدم يطلب بسرعة مفرطة."""
    now = time.monotonic()
    if now - _last_request.get(user_id, 0) < config.RATE_LIMIT_SECONDS:
        return True
    _last_request[user_id] = now
    return False


# ─────────────────────────────────────────────────────────────
# دوال مساعدة
# ─────────────────────────────────────────────────────────────

STATUS_EMOJI: dict[str, str] = {
    "pending":      "⏳",
    "invoice_sent": "📤",
    "paid":         "💳",
    "completed":    "✅",
    "failed":       "❌",
}


async def _notify_admins(
    bot,
    text: str,
    keyboard: Optional[InlineKeyboardMarkup] = None,
) -> None:
    """إرسال إشعار نصي لجميع مسؤولي البوت."""
    for admin_id in config.ADMIN_USER_IDS:
        try:
            await bot.send_message(
                chat_id=admin_id,
                text=text,
                parse_mode=ParseMode.HTML,
                reply_markup=keyboard,
            )
        except TelegramError as exc:
            logger.warning(f"فشل إرسال إشعار للمسؤول {admin_id}: {exc}")


def _is_admin(user_id: int) -> bool:
    return user_id in config.ADMIN_USER_IDS


def _bot_is_active(context: ContextTypes.DEFAULT_TYPE) -> bool:
    return context.bot_data.get("is_active", True)


def _ton_price(context: ContextTypes.DEFAULT_TYPE) -> float:
    return context.bot_data.get("ton_usd_price", 0.0)


# ════════════════════════════════════════════════════════════════
#  JOB QUEUE: تحديث سعر TON كل 5 دقائق
# ════════════════════════════════════════════════════════════════

async def job_update_ton_price(context: ContextTypes.DEFAULT_TYPE) -> None:
    """مهمة دورية: جلب سعر TON/USD وتخزينه في bot_data."""
    try:
        price = ton_utils.get_ton_price_usd()
        context.bot_data["ton_usd_price"] = price
        logger.info(f"[JOB] سعر TON محدَّث: ${price:.4f}")
    except Exception as exc:
        logger.error(f"[JOB] فشل تحديث سعر TON: {exc}")


# ════════════════════════════════════════════════════════════════
#  /start
# ════════════════════════════════════════════════════════════════

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معالج أمر /start — ترحيب مخصص وعرض القائمة الرئيسية."""
    user = update.effective_user
    context.user_data.clear()

    db_user = db.get_or_create_user(
        user_id=user.id,
        username=user.username,
        first_name=user.first_name or "مستخدم",
    )

    if db_user["total_stars_sold"] == 0:
        text = (
            f"✨ <b>مرحباً بك، {user.first_name}!</b>\n\n"
            "🌟 هذا البوت يتيح لك <b>بيع نجوم تيليجرام</b> مقابل عملة <b>TON</b>.\n\n"
            f"💰 سعر الشراء الثابت:\n"
            f"   <b>{config.PRICE_PER_100_STARS_USD}$</b> لكل <b>100 نجمة</b>\n\n"
            f"⭐ الحد الأدنى: <b>{config.MIN_STARS} نجمة</b>\n"
            f"💎 الدفع: مباشرة إلى محفظتك TON\n\n"
            "اختر من القائمة أدناه للبدء:"
        )
    else:
        text = (
            f"👋 <b>أهلاً مجدداً، {user.first_name}!</b>\n\n"
            f"📊 <b>إحصائياتك السريعة:</b>\n"
            f"   ⭐ نجوم مبيعة: <b>{db_user['total_stars_sold']:,}</b>\n"
            f"   💎 TON مستلمة: <b>{db_user['total_ton_received']:.4f}</b>\n\n"
            "ماذا تريد اليوم؟"
        )

    await update.effective_message.reply_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu_keyboard(_is_admin(user.id)),
    )


# ════════════════════════════════════════════════════════════════
#  القائمة الرئيسية (Callback)
# ════════════════════════════════════════════════════════════════

async def cb_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    context.user_data.clear()

    user    = update.effective_user
    db_user = db.get_user(user.id)

    if db_user and db_user["total_stars_sold"] > 0:
        text = (
            f"🏠 <b>القائمة الرئيسية</b>\n\n"
            f"⭐ مبيع: <b>{db_user['total_stars_sold']:,}</b> نجمة  |  "
            f"💎 <b>{db_user['total_ton_received']:.4f} TON</b>"
        )
    else:
        text = "🏠 <b>القائمة الرئيسية</b>\n\nاختر ما تريد:"

    await query.edit_message_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu_keyboard(_is_admin(user.id)),
    )


# ════════════════════════════════════════════════════════════════
#  تدفق البيع — ConversationHandler
# ════════════════════════════════════════════════════════════════

# ── دخول المحادثة ──────────────────────────────────────────────

async def sell_entry(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """نقطة دخول محادثة البيع عند الضغط على 'بيع النجوم'."""
    query = update.callback_query
    user  = update.effective_user

    # تحقق من معدل الطلبات
    if _is_rate_limited(user.id):
        await query.answer("⏳ يرجى الانتظار قليلاً قبل طلب جديد.", show_alert=True)
        return ConversationHandler.END

    # تحقق من الحظر
    if db.is_user_banned(user.id):
        await query.answer(
            "🚫 حسابك محظور من استخدام هذه الخدمة. تواصل مع الدعم.",
            show_alert=True,
        )
        return ConversationHandler.END

    await query.answer()

    # تحقق من حالة البوت
    if not _bot_is_active(context):
        await query.edit_message_text(
            "⚠️ <b>الخدمة متوقفة مؤقتاً</b>\n\n"
            "نعمل على تحسين الخدمة. يرجى المحاولة لاحقاً.",
            parse_mode=ParseMode.HTML,
            reply_markup=back_to_main_keyboard(),
        )
        return ConversationHandler.END

    # تأكد من توفر سعر TON
    price = _ton_price(context)
    if price <= 0:
        try:
            price = ton_utils.get_ton_price_usd()
            context.bot_data["ton_usd_price"] = price
        except Exception:
            await query.edit_message_text(
                "⚠️ <b>تعذّر جلب سعر TON.</b>\n\nيرجى المحاولة بعد دقيقة.",
                parse_mode=ParseMode.HTML,
                reply_markup=back_to_main_keyboard(),
            )
            return ConversationHandler.END

    await query.edit_message_text(
        f"💰 <b>بيع النجوم</b>\n\n"
        f"📈 سعر TON الحالي: <b>${price:.3f}</b>\n"
        f"💵 سعر الشراء: <b>${config.PRICE_PER_100_STARS_USD}</b> / 100 نجمة\n\n"
        f"⭐ <b>كم عدد النجوم التي تريد بيعها؟</b>\n"
        f"<i>الحد الأدنى {config.MIN_STARS} | الحد الأقصى {config.MAX_STARS:,}</i>",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_keyboard(),
    )
    return WAITING_FOR_STAR_COUNT


# ── الحالة 1: عدد النجوم ───────────────────────────────────────

async def handle_star_count(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """معالجة عدد النجوم المُدخَل من المستخدم."""
    raw = update.message.text.strip().replace(",", "").replace("،", "")

    try:
        star_count = int(raw)
    except ValueError:
        await update.message.reply_text(
            "❌ يرجى إدخال <b>رقم صحيح</b> فقط.\n\nمثال: <code>200</code>",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_keyboard(),
        )
        return WAITING_FOR_STAR_COUNT

    if star_count < config.MIN_STARS:
        await update.message.reply_text(
            f"❌ الحد الأدنى هو <b>{config.MIN_STARS} نجمة</b>.\n"
            f"أدخل عدداً أكبر أو يساوي {config.MIN_STARS}.",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_keyboard(),
        )
        return WAITING_FOR_STAR_COUNT

    if star_count > config.MAX_STARS:
        await update.message.reply_text(
            f"❌ الحد الأقصى هو <b>{config.MAX_STARS:,} نجمة</b>.",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_keyboard(),
        )
        return WAITING_FOR_STAR_COUNT

    price = _ton_price(context)
    if price <= 0:
        await update.message.reply_text(
            "⚠️ سعر TON غير متوفر حالياً. يرجى المحاولة لاحقاً.",
            reply_markup=back_to_main_keyboard(),
        )
        return ConversationHandler.END

    ton_amount, usd_amount = ton_utils.calculate_ton_amount(star_count, price)

    # تخزين مؤقت
    context.user_data["star_count"]  = star_count
    context.user_data["ton_amount"]  = ton_amount
    context.user_data["usd_amount"]  = usd_amount

    # محفظة افتراضية؟
    db_user       = db.get_user(update.effective_user.id)
    default_wallet = db_user["wallet_address"] if db_user else None

    prompt = (
        f"✅ ممتاز!\n\n"
        f"⭐ عدد النجوم: <b>{star_count:,}</b>\n"
        f"💎 ستستلم: <b>{ton_amount:.6f} TON</b>\n"
        f"💵 القيمة التقريبية: <b>≈ ${usd_amount:.4f}</b>\n\n"
        f"📍 <b>أدخل عنوان محفظة TON لاستلام مبلغك:</b>"
    )

    if default_wallet:
        prompt += (
            f"\n\n<i>💡 محفظتك المحفوظة:</i>\n"
            f"<code>{default_wallet}</code>"
        )

    await update.message.reply_text(
        prompt,
        parse_mode=ParseMode.HTML,
        reply_markup=wallet_input_keyboard(has_default=bool(default_wallet)),
    )
    return WAITING_FOR_WALLET


# ── الحالة 2: عنوان المحفظة ────────────────────────────────────

async def handle_wallet_text(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """معالجة عنوان المحفظة المُكتَب من المستخدم."""
    wallet = update.message.text.strip()

    if not ton_utils.validate_ton_address(wallet):
        await update.message.reply_text(
            "❌ <b>عنوان المحفظة غير صالح!</b>\n\n"
            "يجب أن يكون بالصيغة الودية (48 حرفاً) أو الخام.\n"
            "<i>مثال: <code>EQD...رموز...48</code></i>\n\n"
            "أعد إدخال العنوان:",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_keyboard(),
        )
        return WAITING_FOR_WALLET

    # حفظ المحفظة كافتراضية
    db.update_user_wallet(update.effective_user.id, wallet)
    context.user_data["wallet_address"] = wallet

    return await _show_confirmation(update.message, context)


async def handle_use_default_wallet(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """استخدام المحفظة الافتراضية المحفوظة."""
    query = update.callback_query
    await query.answer()

    db_user = db.get_user(update.effective_user.id)
    if not db_user or not db_user["wallet_address"]:
        await query.answer("⚠️ لا توجد محفظة افتراضية محفوظة.", show_alert=True)
        return WAITING_FOR_WALLET

    context.user_data["wallet_address"] = db_user["wallet_address"]
    return await _show_confirmation(query, context)


async def _show_confirmation(
    message_or_query,
    context: ContextTypes.DEFAULT_TYPE,
) -> int:
    """عرض ملخص الطلب وطلب التأكيد النهائي."""
    star_count     = context.user_data["star_count"]
    ton_amount     = context.user_data["ton_amount"]
    usd_amount     = context.user_data["usd_amount"]
    wallet_address = context.user_data["wallet_address"]

    text = (
        f"📋 <b>ملخص الطلب — راجع قبل التأكيد</b>\n"
        f"{'─' * 32}\n"
        f"⭐ النجوم المراد بيعها:  <b>{star_count:,}</b>\n"
        f"💎 TON ستستلمها:         <b>{ton_amount:.6f}</b>\n"
        f"💵 القيمة التقريبية:     <b>≈ ${usd_amount:.4f}</b>\n"
        f"📍 محفظة الاستلام:\n"
        f"<code>{wallet_address}</code>\n"
        f"{'─' * 32}\n\n"
        f"⚠️ <b>آلية العملية:</b>\n"
        f"1. ستظهر فاتورة بقيمة <b>{star_count:,} ⭐</b>\n"
        f"2. بعد دفعك، تنتقل النجوم لحساب البوت\n"
        f"3. يُحوَّل <b>{ton_amount:.6f} TON</b> فوراً لمحفظتك\n\n"
        f"هل تريد المتابعة؟"
    )

    if hasattr(message_or_query, "edit_message_text"):
        await message_or_query.edit_message_text(
            text, parse_mode=ParseMode.HTML, reply_markup=confirm_order_keyboard()
        )
    else:
        await message_or_query.reply_text(
            text, parse_mode=ParseMode.HTML, reply_markup=confirm_order_keyboard()
        )
    return CONFIRM_ORDER


# ── الحالة 3: تأكيد وإنشاء الفاتورة ───────────────────────────

async def handle_confirm_order(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """إنشاء المعاملة في قاعدة البيانات وإرسال فاتورة XTR."""
    query = update.callback_query
    await query.answer()

    star_count     = context.user_data.get("star_count")
    ton_amount     = context.user_data.get("ton_amount")
    usd_amount     = context.user_data.get("usd_amount")
    wallet_address = context.user_data.get("wallet_address")

    # تحقق من اكتمال البيانات
    if not all([star_count, ton_amount, wallet_address]):
        await query.edit_message_text(
            "❌ انتهت صلاحية الجلسة. يرجى البدء من جديد.",
            reply_markup=back_to_main_keyboard(),
        )
        context.user_data.clear()
        return ConversationHandler.END

    # توليد معرّف فريد للمعاملة
    unique_id = uuid.uuid4().hex[:12].upper()

    # حفظ المعاملة في قاعدة البيانات
    try:
        db.create_transaction(
            unique_id=unique_id,
            user_id=update.effective_user.id,
            star_count=star_count,
            ton_amount=ton_amount,
            usd_amount=usd_amount or 0.0,
            wallet_address=wallet_address,
        )
    except Exception as exc:
        logger.error(f"خطأ DB عند إنشاء المعاملة: {exc}", exc_info=True)
        await query.edit_message_text(
            "❌ خطأ داخلي. يرجى المحاولة لاحقاً.",
            reply_markup=back_to_main_keyboard(),
        )
        context.user_data.clear()
        return ConversationHandler.END

    await query.edit_message_text(
        "⏳ <b>جارٍ إنشاء فاتورة الدفع...</b>",
        parse_mode=ParseMode.HTML,
    )

    # إرسال فاتورة Telegram Stars
    try:
        await context.bot.send_invoice(
            chat_id=update.effective_user.id,
            title=f"💫 بيع {star_count:,} نجمة",
            description=(
                f"بيع {star_count:,} ⭐ مقابل {ton_amount:.6f} TON\n"
                f"إلى: {wallet_address[:20]}..."
            ),
            payload=unique_id,
            currency="XTR",
            prices=[LabeledPrice(f"⭐ {star_count:,} نجمة تيليجرام", star_count)],
            provider_token="",
            protect_content=True,
        )
        db.update_transaction_status(unique_id, "invoice_sent")
        logger.info(f"فاتورة أُرسلت: {unique_id} | {star_count} نجمة")
    except Exception as exc:
        logger.error(f"فشل إرسال الفاتورة ({unique_id}): {exc}", exc_info=True)
        db.update_transaction_status(unique_id, "failed", error_message=str(exc))
        await context.bot.send_message(
            chat_id=update.effective_user.id,
            text=(
                "❌ <b>فشل إنشاء الفاتورة.</b>\n\n"
                "يرجى المحاولة مجدداً أو التواصل مع الدعم."
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=back_to_main_keyboard(),
        )

    context.user_data.clear()
    return ConversationHandler.END


# ── إلغاء المحادثة ─────────────────────────────────────────────

async def cancel_conversation(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """إلغاء المحادثة الحالية وإعادة المستخدم للقائمة الرئيسية."""
    context.user_data.clear()
    user     = update.effective_user
    is_admin = _is_admin(user.id) if user else False

    text     = "❌ <b>تم إلغاء العملية.</b>\n\nيمكنك البدء من جديد في أي وقت."
    keyboard = main_menu_keyboard(is_admin)

    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(
            text, parse_mode=ParseMode.HTML, reply_markup=keyboard
        )
    elif update.message:
        await update.message.reply_text(
            text, parse_mode=ParseMode.HTML, reply_markup=keyboard
        )
    return ConversationHandler.END


# ── انتهاء مهلة المحادثة ───────────────────────────────────────

async def conversation_timeout(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """تنظيف الجلسة عند انتهاء مهلة المحادثة (5 دقائق)."""
    context.user_data.clear()
    user     = update.effective_user
    is_admin = _is_admin(user.id) if user else False

    timeout_text = (
        "⏰ <b>انتهت مهلة الجلسة!</b>\n\n"
        "تم إلغاء العملية تلقائياً بسبب عدم النشاط لأكثر من 5 دقائق.\n"
        "يمكنك البدء من جديد عبر القائمة الرئيسية."
    )

    try:
        chat_id = update.effective_chat.id if update.effective_chat else None
        if chat_id:
            await context.bot.send_message(
                chat_id=chat_id,
                text=timeout_text,
                parse_mode=ParseMode.HTML,
                reply_markup=main_menu_keyboard(is_admin),
            )
        if update.callback_query:
            await update.callback_query.answer()
    except Exception as exc:
        logger.warning(f"خطأ في معالج timeout: {exc}")

    return ConversationHandler.END


# ════════════════════════════════════════════════════════════════
#  معالجات الدفع
# ════════════════════════════════════════════════════════════════

async def pre_checkout_handler(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """
    التحقق من صحة الدفع قبل إتمامه.
    يُرفض أي دفع لا يتطابق مع المعاملة المسجّلة.
    """
    query   = update.pre_checkout_query
    payload = query.invoice_payload
    user_id = query.from_user.id

    try:
        tx = db.get_transaction_by_payload(payload)

        if not tx:
            await query.answer(
                ok=False,
                error_message="❌ لم يُعثر على هذا الطلب. أنشئ طلباً جديداً."
            )
            logger.warning(f"pre_checkout: payload غير موجود: {payload}")
            return

        # تحقق أن الدافع هو صاحب المعاملة
        if tx["user_id"] != user_id:
            await query.answer(
                ok=False,
                error_message="❌ هذا الطلب لا ينتمي إلى حسابك."
            )
            logger.warning(f"pre_checkout: مطابقة مستخدم فاشلة: {user_id} vs {tx['user_id']}")
            return

        # تحقق من الحالة
        if tx["status"] not in ("pending", "invoice_sent"):
            await query.answer(
                ok=False,
                error_message="❌ هذا الطلب منتهٍ أو تمت معالجته مسبقاً."
            )
            logger.warning(f"pre_checkout: حالة غير صالحة للطلب {payload}: {tx['status']}")
            return

        # تحقق من المبلغ (1 XTR = 1 نجمة)
        if query.total_amount != tx["star_count"]:
            await query.answer(
                ok=False,
                error_message=(
                    f"❌ المبلغ غير متطابق: "
                    f"المتوقع {tx['star_count']} نجمة، "
                    f"المُرسَل {query.total_amount} نجمة."
                )
            )
            logger.error(
                f"pre_checkout: تلاعب بالمبلغ! payload={payload} "
                f"expected={tx['star_count']} got={query.total_amount}"
            )
            return

        await query.answer(ok=True)
        logger.info(f"pre_checkout مقبول: {payload} | {query.total_amount} نجمة")

    except Exception as exc:
        logger.error(f"خطأ حرج في pre_checkout_handler: {exc}", exc_info=True)
        await query.answer(
            ok=False,
            error_message="❌ خطأ تقني مؤقت. يرجى المحاولة لاحقاً."
        )


async def successful_payment_handler(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """
    معالجة الدفع الناجح: تحويل TON إلى محفظة المستخدم.
    في حال فشل التحويل، يتم إشعار المسؤول مع زر إعادة المحاولة.
    """
    payment = update.message.successful_payment
    payload = payment.invoice_payload
    user    = update.effective_user

    logger.info(f"دفع ناجح: payload={payload} | user={user.id} | stars={payment.total_amount}")

    try:
        tx = db.get_transaction_by_payload(payload)
        if not tx:
            logger.error(f"دفع ناجح لكن المعاملة غير موجودة! payload={payload}")
            await update.message.reply_text(
                "⚠️ <b>تم استلام نجومك لكن حدث خطأ في النظام.</b>\n\n"
                f"رقم المعاملة: <code>{payload}</code>\n"
                "تواصل مع الدعم فوراً.",
                parse_mode=ParseMode.HTML,
                reply_markup=back_to_main_keyboard(),
            )
            await _notify_admins(
                context.bot,
                f"🚨 <b>دفع يتيم!</b>\n"
                f"تم الدفع لكن المعاملة غير موجودة في DB!\n"
                f"Payload: <code>{payload}</code>\n"
                f"User: {user.id} | Stars: {payment.total_amount}"
            )
            return

        db.update_transaction_status(payload, "paid")

        # رسالة المعالجة
        msg = await update.message.reply_text(
            f"✅ <b>تم استلام نجومك!</b> ({payment.total_amount:,} ⭐)\n\n"
            f"⏳ جارٍ تحويل <b>{tx['ton_amount']:.6f} TON</b> إلى محفظتك...",
            parse_mode=ParseMode.HTML,
        )

        # إرسال TON
        try:
            tx_hash = ton_utils.send_ton(
                to_address=tx["wallet_address"],
                amount_ton=tx["ton_amount"],
                comment=f"Stars Bot | {payload}",
            )

            db.update_transaction_status(payload, "completed", ton_tx_hash=tx_hash)
            db.update_user_stats(user.id, tx["star_count"], tx["ton_amount"])

            await msg.edit_text(
                f"🎉 <b>اكتملت العملية بنجاح!</b>\n"
                f"{'─' * 30}\n"
                f"⭐ نجوم مبيعة:    <b>{tx['star_count']:,}</b>\n"
                f"💎 TON محوَّلة:   <b>{tx['ton_amount']:.6f}</b>\n"
                f"📍 إلى:           <code>{tx['wallet_address']}</code>\n"
                f"🔑 مرجع TX:       <code>{tx_hash}</code>\n"
                f"{'─' * 30}\n\n"
                f"شكراً لاستخدامك خدمتنا! 🙏",
                parse_mode=ParseMode.HTML,
                reply_markup=back_to_main_keyboard(),
            )
            logger.info(f"تحويل TON مكتمل: {tx['ton_amount']} TON → {tx['wallet_address'][:16]}...")

            # ── إشعار القناة: نجاح ──────────────────────────────
            await notifier.notify_success(
                context,
                transaction_data={
                    "uuid":           payload,
                    "user_id":        user.id,
                    "username":       user.username,
                    "first_name":     user.first_name,
                    "star_amount":    tx["star_count"],
                    "usd_value":      tx["usd_amount"],
                    "ton_price":      _ton_price(context),
                    "ton_amount":     tx["ton_amount"],
                    "wallet_address": tx["wallet_address"],
                    "tx_hash":        tx_hash,
                    "timestamp":      str(tx["created_at"]),
                },
            )

        except Exception as ton_exc:
            logger.error(
                f"فشل تحويل TON بعد استلام النجوم! "
                f"payload={payload} error={ton_exc}",
                exc_info=True,
            )
            db.update_transaction_status(
                payload, "failed", error_message=str(ton_exc)[:500]
            )

            await msg.edit_text(
                f"⚠️ <b>تم استلام نجومك، لكن فشل التحويل مؤقتاً.</b>\n\n"
                f"رقم طلبك: <code>{payload}</code>\n"
                f"سيتواصل معك فريق الدعم لإتمام التحويل يدوياً.\n\n"
                f"اعتذر عن هذا الإزعاج.",
                parse_mode=ParseMode.HTML,
                reply_markup=back_to_main_keyboard(),
            )

            await _notify_admins(
                context.bot,
                f"🚨 <b>فشل تحويل TON!</b>\n"
                f"{'─' * 28}\n"
                f"📋 TX: <code>{payload}</code>\n"
                f"👤 User: {user.id} (@{user.username or 'N/A'})\n"
                f"⭐ النجوم: {tx['star_count']:,}\n"
                f"💎 TON:   {tx['ton_amount']:.6f}\n"
                f"📍 محفظة: <code>{tx['wallet_address']}</code>\n"
                f"❌ خطأ:   <code>{str(ton_exc)[:300]}</code>",
                keyboard=retry_transfer_keyboard(payload),
            )

            # ── إشعار القناة: فشل ──────────────────────────────
            await notifier.notify_failure(
                context,
                transaction_data={
                    "uuid":       payload,
                    "user_id":    user.id,
                    "username":   user.username,
                    "first_name": user.first_name,
                    "star_amount": tx["star_count"],
                    "timestamp":  str(tx["created_at"]),
                },
                error_message=str(ton_exc),
            )

    except Exception as fatal_exc:
        logger.critical(
            f"خطأ فادح في successful_payment_handler: {fatal_exc}", exc_info=True
        )
        await update.message.reply_text(
            "⚠️ حدث خطأ غير متوقع. تواصل مع الدعم بالرجاء.",
            reply_markup=back_to_main_keyboard(),
        )


# ════════════════════════════════════════════════════════════════
#  رصيدي وإحصائياتي
# ════════════════════════════════════════════════════════════════

async def cb_my_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    user    = update.effective_user
    db_user = db.get_user(user.id)

    if not db_user:
        await query.edit_message_text(
            "❌ لم يُعثر على بياناتك.", reply_markup=back_to_main_keyboard()
        )
        return

    wallet_info = (
        f"\n<code>{db_user['wallet_address']}</code>"
        if db_user["wallet_address"]
        else " <i>غير محددة</i>"
    )

    text = (
        f"📊 <b>إحصائياتك</b>\n"
        f"{'─' * 30}\n"
        f"👤 معرّفك: <code>{user.id}</code>\n"
        f"⭐ نجوم مبيعة:    <b>{db_user['total_stars_sold']:,}</b>\n"
        f"💎 TON مستلمة:   <b>{db_user['total_ton_received']:.6f}</b>\n"
        f"📍 محفظتك الافتراضية:{wallet_info}\n"
        f"📅 عضو منذ: <i>{str(db_user['created_at'])[:10]}</i>\n"
        f"🕐 آخر نشاط: <i>{str(db_user['last_active'])[:16]}</i>"
    )

    await query.edit_message_text(
        text, parse_mode=ParseMode.HTML, reply_markup=back_to_main_keyboard()
    )


# ════════════════════════════════════════════════════════════════
#  سجل المعاملات (مع ترقيم)
# ════════════════════════════════════════════════════════════════

async def cb_tx_history(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    user     = update.effective_user
    page     = int(query.data.split(":")[1])
    per_page = 5

    txs, total = db.get_user_transactions(user.id, page, per_page)
    total_pages = max(1, (total + per_page - 1) // per_page)

    if not txs:
        await query.edit_message_text(
            "🧾 <b>سجل المعاملات</b>\n\nلا توجد معاملات بعد.\nابدأ ببيع نجومك!",
            parse_mode=ParseMode.HTML,
            reply_markup=back_to_main_keyboard(),
        )
        return

    lines = [
        f"🧾 <b>سجل المعاملاتك</b>  (صفحة {page + 1}/{total_pages})\n{'─' * 30}"
    ]
    for tx in txs:
        emoji = STATUS_EMOJI.get(tx["status"], "❓")
        lines.append(
            f"\n{emoji} <b>{tx['star_count']:,} ⭐ → {tx['ton_amount']:.4f} TON</b>\n"
            f"   🔑 <code>{tx['unique_id']}</code>\n"
            f"   📅 {str(tx['created_at'])[:16]}"
        )

    await query.edit_message_text(
        "\n".join(lines),
        parse_mode=ParseMode.HTML,
        reply_markup=pagination_keyboard(page, total_pages),
    )


# ════════════════════════════════════════════════════════════════
#  الدعم
# ════════════════════════════════════════════════════════════════

async def cb_support(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    await query.edit_message_text(
        f"🛡️ <b>الدعم والمساعدة</b>\n\n"
        f"للتواصل مع فريق الدعم:\n"
        f"👉 {config.SUPPORT_USERNAME}\n\n"
        f"عند التواصل، يرجى ذكر:\n"
        f"• رقم المعاملة (unique_id)\n"
        f"• وصف المشكلة\n\n"
        f"⏱ وقت الاستجابة: خلال 24 ساعة",
        parse_mode=ParseMode.HTML,
        reply_markup=back_to_main_keyboard(),
    )


# ════════════════════════════════════════════════════════════════
#  لوحة التحكم — المسؤول
# ════════════════════════════════════════════════════════════════

async def cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """أمر /admin — يُظهر لوحة التحكم للمسؤولين."""
    if not _is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ ليس لديك صلاحية الوصول.")
        return
    status = "🟢 مفعّل" if _bot_is_active(context) else "🔴 متوقف"
    await update.message.reply_text(
        f"⚙️ <b>لوحة التحكم</b>\n\nحالة البوت: {status}",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_panel_keyboard(),
    )


async def cb_admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not _is_admin(update.effective_user.id):
        await query.answer("⛔", show_alert=True)
        return
    await query.answer()
    status = "🟢 مفعّل" if _bot_is_active(context) else "🔴 متوقف"
    price  = _ton_price(context)
    await query.edit_message_text(
        f"⚙️ <b>لوحة تحكم المسؤول</b>\n\n"
        f"حالة البوت: {status}\n"
        f"سعر TON: <b>${price:.3f}</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_panel_keyboard(),
    )


async def cb_admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not _is_admin(update.effective_user.id):
        await query.answer("⛔", show_alert=True)
        return
    await query.answer("⏳ جارٍ جلب الإحصائيات...")

    stats     = db.get_transaction_stats()
    ton_price = _ton_price(context)

    try:
        ton_balance = ton_utils.get_bot_ton_balance()
        balance_txt = f"<b>{ton_balance:.4f} TON</b>"
    except Exception:
        balance_txt = "<i>تعذّر جلب الرصيد</i>"

    text = (
        f"📊 <b>إحصائيات النظام</b>\n"
        f"{'─' * 32}\n"
        f"👥 إجمالي المستخدمين: <b>{stats['user_count']}</b>\n"
        f"📋 إجمالي المعاملات:  <b>{stats['total']}</b>\n"
        f"   ✅ مكتملة:          <b>{stats['completed']}</b>\n"
        f"   ⏳ معلّقة:          <b>{stats['pending']}</b>\n"
        f"   ❌ فاشلة:           <b>{stats['failed']}</b>\n"
        f"{'─' * 32}\n"
        f"⭐ نجوم مشتراة:      <b>{stats['total_stars_bought']:,}</b>\n"
        f"💎 TON محوَّلة:      <b>{stats['total_ton_paid']:.4f}</b>\n"
        f"{'─' * 32}\n"
        f"💰 رصيد البوت (TON): {balance_txt}\n"
        f"📈 سعر TON:          <b>${ton_price:.3f}</b>"
    )

    await query.edit_message_text(
        text, parse_mode=ParseMode.HTML, reply_markup=admin_stats_keyboard()
    )


async def cb_admin_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not _is_admin(update.effective_user.id):
        await query.answer("⛔", show_alert=True)
        return

    current = _bot_is_active(context)
    context.bot_data["is_active"] = not current
    new_label = "🟢 مفعّل" if not current else "🔴 متوقف"

    await query.answer(f"تم تغيير الحالة: {new_label}", show_alert=True)
    await query.edit_message_text(
        f"⚙️ <b>لوحة تحكم المسؤول</b>\n\nحالة البوت: {new_label}",
        parse_mode=ParseMode.HTML,
        reply_markup=admin_panel_keyboard(),
    )
    logger.info(f"المسؤول {update.effective_user.id} غيّر حالة البوت إلى: {new_label}")


async def cb_admin_recent_tx(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    query = update.callback_query
    if not _is_admin(update.effective_user.id):
        await query.answer("⛔", show_alert=True)
        return
    await query.answer()

    txs = db.get_recent_transactions(10)
    if not txs:
        text = "🔍 لا توجد معاملات بعد."
    else:
        lines = [f"🔍 <b>آخر 10 معاملات</b>\n{'─' * 30}"]
        for tx in txs:
            emoji = STATUS_EMOJI.get(tx["status"], "❓")
            lines.append(
                f"\n{emoji} <code>{tx['unique_id']}</code>\n"
                f"   👤 {tx['user_id']} | ⭐ {tx['star_count']:,} | 💎 {tx['ton_amount']:.4f}\n"
                f"   📅 {str(tx['created_at'])[:16]}"
            )
        text = "\n".join(lines)

    await query.edit_message_text(
        text, parse_mode=ParseMode.HTML, reply_markup=admin_recent_tx_keyboard()
    )


async def cb_admin_retry(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """إعادة محاولة تحويل TON بعد فشله — للمسؤول فقط."""
    query = update.callback_query
    if not _is_admin(update.effective_user.id):
        await query.answer("⛔", show_alert=True)
        return

    unique_id = query.data.split(":", 1)[1]
    await query.answer("⏳ جارٍ إعادة المحاولة...")

    tx = db.get_transaction_by_unique_id(unique_id)
    if not tx:
        await query.edit_message_text("❌ لم يُعثر على المعاملة.")
        return

    try:
        tx_hash = ton_utils.send_ton(
            to_address=tx["wallet_address"],
            amount_ton=tx["ton_amount"],
            comment=f"Stars Bot Retry | {unique_id}",
        )
        db.update_transaction_status(unique_id, "completed", ton_tx_hash=tx_hash)
        db.update_user_stats(tx["user_id"], tx["star_count"], tx["ton_amount"])

        await query.edit_message_text(
            f"✅ <b>إعادة المحاولة نجحت!</b>\n"
            f"المعاملة: <code>{unique_id}</code>\n"
            f"المبلغ: {tx['ton_amount']:.6f} TON\n"
            f"المرجع: <code>{tx_hash}</code>",
            parse_mode=ParseMode.HTML,
        )

        # إشعار المستخدم
        try:
            await context.bot.send_message(
                chat_id=tx["user_id"],
                text=(
                    f"✅ <b>تم إكمال معاملتك!</b>\n\n"
                    f"تم تحويل <b>{tx['ton_amount']:.6f} TON</b> إلى محفظتك.\n"
                    f"مرجع: <code>{tx_hash}</code>"
                ),
                parse_mode=ParseMode.HTML,
                reply_markup=back_to_main_keyboard(),
            )
        except TelegramError:
            pass  # المستخدم ربما أوقف البوت

        logger.info(f"إعادة محاولة ناجحة للمعاملة {unique_id}")

    except Exception as exc:
        logger.error(f"فشلت إعادة المحاولة للمعاملة {unique_id}: {exc}")
        await query.edit_message_text(
            f"❌ <b>فشلت إعادة المحاولة!</b>\n"
            f"خطأ: <code>{str(exc)[:300]}</code>",
            parse_mode=ParseMode.HTML,
            reply_markup=retry_transfer_keyboard(unique_id),
        )


# ════════════════════════════════════════════════════════════════
#  بث رسالة — ConversationHandler للمسؤول
# ════════════════════════════════════════════════════════════════

async def cb_admin_broadcast_entry(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    query = update.callback_query
    if not _is_admin(update.effective_user.id):
        await query.answer("⛔", show_alert=True)
        return ConversationHandler.END
    await query.answer()

    user_count = len(db.get_all_user_ids())
    await query.edit_message_text(
        f"📝 <b>بث رسالة للجميع</b>\n\n"
        f"عدد المستقبلين: <b>{user_count}</b> مستخدم\n\n"
        f"أرسل الآن نص الرسالة (يدعم HTML).\n"
        f"اضغط إلغاء للتراجع.",
        parse_mode=ParseMode.HTML,
        reply_markup=broadcast_cancel_keyboard(),
    )
    return BROADCAST_MESSAGE


async def handle_broadcast_text(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    """إرسال الرسالة المبثوثة لجميع المستخدمين."""
    if not _is_admin(update.effective_user.id):
        return ConversationHandler.END

    msg_text   = update.message.text
    user_ids   = db.get_all_user_ids()
    status_msg = await update.message.reply_text(
        f"📤 جارٍ الإرسال لـ <b>{len(user_ids)}</b> مستخدم...",
        parse_mode=ParseMode.HTML,
    )

    sent   = 0
    failed = 0

    for uid in user_ids:
        try:
            await context.bot.send_message(
                chat_id=uid,
                text=f"📢 <b>إعلان رسمي</b>\n\n{msg_text}",
                parse_mode=ParseMode.HTML,
            )
            sent += 1
        except TelegramError:
            failed += 1
        await asyncio.sleep(0.05)  # تجنّب Flood

    await status_msg.edit_text(
        f"✅ <b>اكتمل البث!</b>\n\n"
        f"✓ أُرسل: <b>{sent}</b>\n"
        f"✗ فشل:  <b>{failed}</b>",
        parse_mode=ParseMode.HTML,
    )
    return ConversationHandler.END


async def cb_cancel_broadcast(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        "❌ تم إلغاء البث.",
        reply_markup=admin_panel_keyboard(),
    )
    return ConversationHandler.END


# ════════════════════════════════════════════════════════════════
#  معالج tx_page_info (زر معلومات غير قابل للنقر)
# ════════════════════════════════════════════════════════════════

async def cb_noop(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.callback_query.answer()


# ════════════════════════════════════════════════════════════════
#  معالج الأخطاء العام
# ════════════════════════════════════════════════════════════════

async def error_handler(
    update: object, context: ContextTypes.DEFAULT_TYPE
) -> None:
    logger.error(f"استثناء غير معالج: {context.error}", exc_info=context.error)
    if isinstance(update, Update) and update.effective_message:
        try:
            await update.effective_message.reply_text(
                "⚠️ حدث خطأ غير متوقع. يرجى المحاولة لاحقاً.",
                reply_markup=back_to_main_keyboard(),
            )
        except Exception:
            pass


# ════════════════════════════════════════════════════════════════
#  بناء وتشغيل التطبيق
# ════════════════════════════════════════════════════════════════

async def post_init(application: Application) -> None:
    """تهيئة قاعدة البيانات وأوامر البوت عند الإطلاق."""
    db.init_db()
    db.migrate_db()   # ترقية المخطط لدعم الميزات الجديدة

    application.bot_data.setdefault("is_active", True)
    application.bot_data.setdefault("ton_usd_price", 0.0)

    # تحميل الإعدادات الديناميكية من قاعدة البيانات
    saved_channel = db.get_setting("notification_channel")
    if saved_channel is not None:
        config.NOTIFICATION_CHANNEL = saved_channel  # type: ignore[attr-defined]

    saved_min = db.get_setting("min_stars_override")
    if saved_min is not None:
        config.MIN_STARS = int(saved_min)

    await application.bot.set_my_commands([
        BotCommand("start",  "القائمة الرئيسية"),
        BotCommand("admin",  "لوحة التحكم (للمسؤولين)"),
        BotCommand("cancel", "إلغاء العملية الحالية"),
    ])
    logger.info("البوت جاهز للتشغيل ✅")


def build_application() -> Application:
    """بناء وإعداد تطبيق البوت مع جميع الـ Handlers."""

    app = (
        Application.builder()
        .token(config.BOT_TOKEN)
        .post_init(post_init)
        .build()
    )

    # ── ConversationHandler: تدفق البيع ───────────────────────
    sell_conv = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(sell_entry, pattern="^sell_stars$")
        ],
        states={
            WAITING_FOR_STAR_COUNT: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND, handle_star_count
                ),
                CallbackQueryHandler(cancel_conversation, pattern="^cancel$"),
            ],
            WAITING_FOR_WALLET: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND, handle_wallet_text
                ),
                CallbackQueryHandler(
                    handle_use_default_wallet, pattern="^use_default_wallet$"
                ),
                CallbackQueryHandler(cancel_conversation, pattern="^cancel$"),
            ],
            CONFIRM_ORDER: [
                CallbackQueryHandler(
                    handle_confirm_order, pattern="^confirm_order$"
                ),
                CallbackQueryHandler(cancel_conversation, pattern="^cancel$"),
            ],
            ConversationHandler.TIMEOUT: [
                MessageHandler(filters.ALL, conversation_timeout),
                CallbackQueryHandler(conversation_timeout),
            ],
        },
        fallbacks=[
            CommandHandler("cancel", cancel_conversation),
            CommandHandler("start",  cmd_start),
            CallbackQueryHandler(cancel_conversation, pattern="^cancel$"),
        ],
        conversation_timeout=config.CONVERSATION_TIMEOUT,
        allow_reentry=True,
        name="sell_flow",
        persistent=False,
    )

    # ── ConversationHandler: بث المسؤول ───────────────────────
    broadcast_conv = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(
                cb_admin_broadcast_entry, pattern="^admin_broadcast$"
            )
        ],
        states={
            BROADCAST_MESSAGE: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND, handle_broadcast_text
                ),
                CallbackQueryHandler(
                    cb_cancel_broadcast, pattern="^cancel_broadcast$"
                ),
            ],
        },
        fallbacks=[
            CommandHandler("cancel", cb_cancel_broadcast),
        ],
        name="broadcast_flow",
        persistent=False,
    )

    # ── تسجيل الـ Handlers بالأولوية ─────────────────────────
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("admin", cmd_admin))
    app.add_handler(sell_conv)
    app.add_handler(broadcast_conv)
    app.add_handler(PreCheckoutQueryHandler(pre_checkout_handler))
    app.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, successful_payment_handler))

    # ── handlers لوحة التحكم المتقدمة (تُسجَّل قبل الـ callbacks العامة) ──
    admin_module.register_admin_handlers(app)

    # Callbacks عامة
    app.add_handler(CallbackQueryHandler(cb_main_menu,        pattern="^main_menu$"))
    app.add_handler(CallbackQueryHandler(cb_my_stats,         pattern="^my_stats$"))
    app.add_handler(CallbackQueryHandler(cb_tx_history,       pattern=r"^tx_history:\d+$"))
    app.add_handler(CallbackQueryHandler(cb_noop,             pattern="^tx_page_info$"))
    app.add_handler(CallbackQueryHandler(cb_support,          pattern="^support$"))
    app.add_handler(CallbackQueryHandler(cb_admin_panel,      pattern="^admin_panel$"))
    app.add_handler(CallbackQueryHandler(cb_admin_stats,      pattern="^admin_stats$"))
    app.add_handler(CallbackQueryHandler(cb_admin_toggle,     pattern="^admin_toggle$"))
    app.add_handler(CallbackQueryHandler(cb_admin_recent_tx,  pattern="^admin_recent_tx$"))
    app.add_handler(CallbackQueryHandler(cb_admin_retry,      pattern=r"^admin_retry:.+$"))

    # ── مهمة تحديث سعر TON كل 5 دقائق ───────────────────────
    app.job_queue.run_repeating(
        job_update_ton_price,
        interval=config.PRICE_UPDATE_INTERVAL,
        first=5,
        name="ton_price_update",
    )

    app.add_error_handler(error_handler)
    return app


def main() -> None:
    logger.info("جارٍ تشغيل بوت نجوم تيليجرام... 🚀")
    app = build_application()
    app.run_polling(
        allowed_updates=Update.ALL_TYPES,
        drop_pending_updates=True,
    )


if __name__ == "__main__":
    main()
