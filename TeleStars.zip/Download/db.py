# ════════════════════════════════════════════════════════════════
#  db.py  —  طبقة قاعدة البيانات SQLite
# ════════════════════════════════════════════════════════════════

import sqlite3
import logging
from typing import Optional

import config

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────
# اتصال قاعدة البيانات
# ─────────────────────────────────────────────────────────────

def get_connection() -> sqlite3.Connection:
    """فتح اتصال بقاعدة البيانات مع إعدادات الأداء والأمان."""
    conn = sqlite3.connect(config.DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


# ─────────────────────────────────────────────────────────────
# تهيئة قاعدة البيانات
# ─────────────────────────────────────────────────────────────

def init_db() -> None:
    """إنشاء الجداول والفهارس إن لم تكن موجودة."""
    with get_connection() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                user_id             INTEGER PRIMARY KEY,
                username            TEXT,
                first_name          TEXT NOT NULL DEFAULT 'مستخدم',
                wallet_address      TEXT,
                total_stars_sold    INTEGER NOT NULL DEFAULT 0,
                total_ton_received  REAL    NOT NULL DEFAULT 0.0,
                created_at          TEXT    NOT NULL DEFAULT (datetime('now')),
                last_active         TEXT    NOT NULL DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS transactions (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                unique_id       TEXT    NOT NULL UNIQUE,
                user_id         INTEGER NOT NULL,
                star_count      INTEGER NOT NULL,
                ton_amount      REAL    NOT NULL,
                usd_amount      REAL    NOT NULL,
                wallet_address  TEXT    NOT NULL,
                status          TEXT    NOT NULL DEFAULT 'pending',
                invoice_payload TEXT,
                ton_tx_hash     TEXT,
                error_message   TEXT,
                created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
                updated_at      TEXT    NOT NULL DEFAULT (datetime('now')),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            );

            CREATE INDEX IF NOT EXISTS idx_tx_user_id
                ON transactions(user_id);
            CREATE INDEX IF NOT EXISTS idx_tx_status
                ON transactions(status);
            CREATE INDEX IF NOT EXISTS idx_tx_unique_id
                ON transactions(unique_id);
            CREATE INDEX IF NOT EXISTS idx_tx_payload
                ON transactions(invoice_payload);
        """)
    logger.info("تم تهيئة قاعدة البيانات بنجاح.")


# ─────────────────────────────────────────────────────────────
# جدول المستخدمين
# ─────────────────────────────────────────────────────────────

def get_or_create_user(
    user_id: int,
    username: Optional[str],
    first_name: str
) -> sqlite3.Row:
    """إنشاء مستخدم جديد أو تحديث بيانات مستخدم موجود، ثم إعادته."""
    with get_connection() as conn:
        existing = conn.execute(
            "SELECT * FROM users WHERE user_id = ?", (user_id,)
        ).fetchone()

        if existing:
            conn.execute(
                """UPDATE users
                   SET username    = ?,
                       first_name  = ?,
                       last_active = datetime('now')
                   WHERE user_id = ?""",
                (username, first_name, user_id)
            )
        else:
            conn.execute(
                """INSERT INTO users (user_id, username, first_name)
                   VALUES (?, ?, ?)""",
                (user_id, username, first_name)
            )

        return conn.execute(
            "SELECT * FROM users WHERE user_id = ?", (user_id,)
        ).fetchone()


def get_user(user_id: int) -> Optional[sqlite3.Row]:
    """جلب بيانات مستخدم بمعرفه."""
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM users WHERE user_id = ?", (user_id,)
        ).fetchone()


def update_user_wallet(user_id: int, wallet_address: str) -> None:
    """تحديث عنوان المحفظة الافتراضي للمستخدم."""
    with get_connection() as conn:
        conn.execute(
            "UPDATE users SET wallet_address = ? WHERE user_id = ?",
            (wallet_address, user_id)
        )


def update_user_stats(user_id: int, star_count: int, ton_amount: float) -> None:
    """تحديث إجمالي النجوم المبيعة والـ TON المستلمة للمستخدم."""
    with get_connection() as conn:
        conn.execute(
            """UPDATE users
               SET total_stars_sold   = total_stars_sold   + ?,
                   total_ton_received = total_ton_received + ?
               WHERE user_id = ?""",
            (star_count, ton_amount, user_id)
        )


def get_all_user_ids() -> list[int]:
    """جلب معرفات جميع المستخدمين (للبث الجماعي)."""
    with get_connection() as conn:
        rows = conn.execute("SELECT user_id FROM users").fetchall()
        return [row["user_id"] for row in rows]


# ─────────────────────────────────────────────────────────────
# جدول المعاملات
# ─────────────────────────────────────────────────────────────

def create_transaction(
    unique_id: str,
    user_id: int,
    star_count: int,
    ton_amount: float,
    usd_amount: float,
    wallet_address: str
) -> None:
    """إنشاء سجل معاملة جديدة بحالة 'pending'."""
    with get_connection() as conn:
        conn.execute(
            """INSERT INTO transactions
               (unique_id, user_id, star_count, ton_amount,
                usd_amount, wallet_address, invoice_payload, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')""",
            (unique_id, user_id, star_count, ton_amount,
             usd_amount, wallet_address, unique_id)
        )
    logger.info(f"معاملة جديدة: {unique_id} | {star_count} نجمة | {ton_amount:.6f} TON")


def get_transaction_by_payload(payload: str) -> Optional[sqlite3.Row]:
    """جلب معاملة عبر invoice_payload (يساوي unique_id)."""
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM transactions WHERE invoice_payload = ?", (payload,)
        ).fetchone()


def get_transaction_by_unique_id(unique_id: str) -> Optional[sqlite3.Row]:
    """جلب معاملة عبر unique_id."""
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM transactions WHERE unique_id = ?", (unique_id,)
        ).fetchone()


def update_transaction_status(
    unique_id: str,
    status: str,
    ton_tx_hash: Optional[str] = None,
    error_message: Optional[str] = None
) -> None:
    """تحديث حالة المعاملة مع hash التحويل أو رسالة الخطأ اختيارياً."""
    with get_connection() as conn:
        conn.execute(
            """UPDATE transactions
               SET status        = ?,
                   ton_tx_hash   = COALESCE(?, ton_tx_hash),
                   error_message = COALESCE(?, error_message),
                   updated_at    = datetime('now')
               WHERE unique_id = ?""",
            (status, ton_tx_hash, error_message, unique_id)
        )
    logger.info(f"حالة المعاملة {unique_id}: {status}")


def get_user_transactions(
    user_id: int,
    page: int = 0,
    per_page: int = 5
) -> tuple[list[sqlite3.Row], int]:
    """جلب معاملات مستخدم مع ترقيم الصفحات. يُعيد (المعاملات، الإجمالي)."""
    with get_connection() as conn:
        total: int = conn.execute(
            "SELECT COUNT(*) FROM transactions WHERE user_id = ?", (user_id,)
        ).fetchone()[0]

        rows = conn.execute(
            """SELECT * FROM transactions
               WHERE user_id = ?
               ORDER BY created_at DESC
               LIMIT ? OFFSET ?""",
            (user_id, per_page, page * per_page)
        ).fetchall()

        return list(rows), total


def get_recent_transactions(limit: int = 10) -> list[sqlite3.Row]:
    """جلب آخر N معاملة من جميع المستخدمين (للوحة المسؤول)."""
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM transactions ORDER BY created_at DESC LIMIT ?",
            (limit,)
        ).fetchall()


def get_transaction_stats() -> dict:
    """إحصائيات شاملة للمعاملات (للوحة المسؤول)."""
    with get_connection() as conn:
        def scalar(q, *args):
            return conn.execute(q, args).fetchone()[0]

        return {
            "total":              scalar("SELECT COUNT(*) FROM transactions"),
            "completed":          scalar("SELECT COUNT(*) FROM transactions WHERE status='completed'"),
            "pending":            scalar(
                "SELECT COUNT(*) FROM transactions WHERE status IN ('pending','invoice_sent','paid')"
            ),
            "failed":             scalar("SELECT COUNT(*) FROM transactions WHERE status='failed'"),
            "total_ton_paid":     scalar(
                "SELECT COALESCE(SUM(ton_amount),0) FROM transactions WHERE status='completed'"
            ),
            "total_stars_bought": scalar(
                "SELECT COALESCE(SUM(star_count),0) FROM transactions WHERE status='completed'"
            ),
            "user_count":         scalar("SELECT COUNT(*) FROM users"),
        }


# ═══════════════════════════════════════════════════════════════
#  إضافات v2 — نظام التحكم الإداري المتقدم
# ═══════════════════════════════════════════════════════════════

def migrate_db() -> None:
    """
    ترقية مخطط قاعدة البيانات لدعم الميزات الجديدة.
    آمن تماماً — يستخدم IF NOT EXISTS وALTER TABLE الشرطي.
    """
    with get_connection() as conn:
        # إضافة عمود banned لجدول users إن لم يكن موجوداً
        cols = {r[1] for r in conn.execute("PRAGMA table_info(users)").fetchall()}
        if "banned" not in cols:
            conn.execute("ALTER TABLE users ADD COLUMN banned INTEGER NOT NULL DEFAULT 0")
            logger.info("تم إضافة عمود banned إلى جدول users")

        # جدول الإعدادات الديناميكية
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS bot_settings (
                key        TEXT PRIMARY KEY,
                value      TEXT NOT NULL,
                updated_at TEXT NOT NULL DEFAULT (datetime('now'))
            );

            -- فهرس إضافي لتسريع استعلامات الفترات الزمنية
            CREATE INDEX IF NOT EXISTS idx_tx_created_at
                ON transactions(created_at);
        """)
    logger.info("migrate_db: اكتمل الترقية بنجاح.")


# ─────────────────────────────────────────────────────────────
# إعدادات ديناميكية (bot_settings)
# ─────────────────────────────────────────────────────────────

def get_setting(key: str, default: Optional[str] = None) -> Optional[str]:
    """قراءة إعداد من جدول bot_settings."""
    with get_connection() as conn:
        row = conn.execute(
            "SELECT value FROM bot_settings WHERE key = ?", (key,)
        ).fetchone()
        return row["value"] if row else default


def set_setting(key: str, value: str) -> None:
    """حفظ أو تحديث إعداد في جدول bot_settings."""
    with get_connection() as conn:
        conn.execute(
            """INSERT INTO bot_settings (key, value, updated_at)
               VALUES (?, ?, datetime('now'))
               ON CONFLICT(key) DO UPDATE
               SET value = excluded.value, updated_at = excluded.updated_at""",
            (key, value)
        )
    logger.info(f"تم تحديث الإعداد: {key} = {value}")


# ─────────────────────────────────────────────────────────────
# معاملات اليوم (مقسّمة بصفحات)
# ─────────────────────────────────────────────────────────────

def get_today_transactions(
    page: int = 0, per_page: int = 5
) -> tuple[list[sqlite3.Row], int]:
    """جلب معاملات اليوم الحالي مع ترقيم الصفحات."""
    with get_connection() as conn:
        total: int = conn.execute(
            """SELECT COUNT(*) FROM transactions
               WHERE date(created_at) = date('now')"""
        ).fetchone()[0]

        rows = conn.execute(
            """SELECT t.*, u.username, u.first_name
               FROM transactions t
               LEFT JOIN users u ON t.user_id = u.user_id
               WHERE date(t.created_at) = date('now')
               ORDER BY t.created_at DESC
               LIMIT ? OFFSET ?""",
            (per_page, page * per_page)
        ).fetchall()

        return list(rows), total


# ─────────────────────────────────────────────────────────────
# تقارير الفترات الزمنية
# ─────────────────────────────────────────────────────────────

def get_report_data(days: int) -> dict:
    """
    إحصائيات مجمّعة للمعاملات المكتملة خلال آخر N يوم.
    يُعيد قاموساً شاملاً للتقرير.
    """
    with get_connection() as conn:
        def scalar(q):
            return conn.execute(
                q, (days,)
            ).fetchone()[0]

        completed_q = """
            SELECT COUNT(*) FROM transactions
            WHERE status = 'completed'
              AND created_at >= datetime('now', ? || ' days')
        """.replace("?", f"-{days}")

        stars_q = """
            SELECT COALESCE(SUM(star_count), 0) FROM transactions
            WHERE status = 'completed'
              AND created_at >= datetime('now', '-' || ? || ' days')
        """
        ton_q = stars_q.replace("star_count", "ton_amount")
        usd_q = stars_q.replace("star_count", "usd_amount")
        total_q = stars_q.replace("status = 'completed' AND ", "")

        def s(q):
            return conn.execute(q, (days,)).fetchone()[0]

        return {
            "days":             days,
            "completed":        s("""SELECT COUNT(*) FROM transactions
                                    WHERE status='completed'
                                      AND created_at >= datetime('now','-'||?||' days')"""),
            "total_tx":         s("""SELECT COUNT(*) FROM transactions
                                    WHERE created_at >= datetime('now','-'||?||' days')"""),
            "total_stars":      s("""SELECT COALESCE(SUM(star_count),0) FROM transactions
                                    WHERE status='completed'
                                      AND created_at >= datetime('now','-'||?||' days')"""),
            "total_ton":        s("""SELECT COALESCE(SUM(ton_amount),0) FROM transactions
                                    WHERE status='completed'
                                      AND created_at >= datetime('now','-'||?||' days')"""),
            "total_usd":        s("""SELECT COALESCE(SUM(usd_amount),0) FROM transactions
                                    WHERE status='completed'
                                      AND created_at >= datetime('now','-'||?||' days')"""),
        }


def get_top_sellers(days: int, limit: int = 5) -> list[sqlite3.Row]:
    """أكثر المستخدمين مبيعاً خلال الفترة (مع username)."""
    with get_connection() as conn:
        return conn.execute(
            """SELECT t.user_id,
                      u.username,
                      u.first_name,
                      SUM(t.star_count) AS total_stars,
                      SUM(t.ton_amount) AS total_ton
               FROM transactions t
               LEFT JOIN users u ON t.user_id = u.user_id
               WHERE t.status = 'completed'
                 AND t.created_at >= datetime('now', '-' || ? || ' days')
               GROUP BY t.user_id
               ORDER BY total_stars DESC
               LIMIT ?""",
            (days, limit)
        ).fetchall()


def get_transactions_for_export(days: int) -> list[sqlite3.Row]:
    """جلب جميع معاملات الفترة لتصدير CSV."""
    with get_connection() as conn:
        return conn.execute(
            """SELECT t.unique_id,
                      u.username,
                      u.first_name,
                      t.user_id,
                      t.star_count,
                      t.ton_amount,
                      t.usd_amount,
                      t.wallet_address,
                      t.status,
                      t.ton_tx_hash,
                      t.created_at
               FROM transactions t
               LEFT JOIN users u ON t.user_id = u.user_id
               WHERE t.created_at >= datetime('now', '-' || ? || ' days')
               ORDER BY t.created_at DESC""",
            (days,)
        ).fetchall()


# ─────────────────────────────────────────────────────────────
# البحث
# ─────────────────────────────────────────────────────────────

def search_transactions_by_username(
    username: str, limit: int = 10
) -> list[sqlite3.Row]:
    """البحث عن معاملات مستخدم باسمه (بدون @)."""
    pattern = f"%{username.lstrip('@')}%"
    with get_connection() as conn:
        return conn.execute(
            """SELECT t.*, u.username, u.first_name
               FROM transactions t
               LEFT JOIN users u ON t.user_id = u.user_id
               WHERE u.username LIKE ?
               ORDER BY t.created_at DESC
               LIMIT ?""",
            (pattern, limit)
        ).fetchall()


def search_transactions_by_user_id(
    user_id: int, limit: int = 10
) -> list[sqlite3.Row]:
    """البحث عن معاملات مستخدم بمعرفه الرقمي."""
    with get_connection() as conn:
        return conn.execute(
            """SELECT t.*, u.username, u.first_name
               FROM transactions t
               LEFT JOIN users u ON t.user_id = u.user_id
               WHERE t.user_id = ?
               ORDER BY t.created_at DESC
               LIMIT ?""",
            (user_id, limit)
        ).fetchall()


def search_transaction_by_uuid(unique_id: str) -> Optional[sqlite3.Row]:
    """البحث عن معاملة بمعرّفها الفريد مع بيانات المستخدم."""
    with get_connection() as conn:
        return conn.execute(
            """SELECT t.*, u.username, u.first_name
               FROM transactions t
               LEFT JOIN users u ON t.user_id = u.user_id
               WHERE t.unique_id = ?""",
            (unique_id.upper(),)
        ).fetchone()


def get_user_by_username(username: str) -> Optional[sqlite3.Row]:
    """جلب مستخدم بـ username (بدون @)."""
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM users WHERE username = ? COLLATE NOCASE",
            (username.lstrip("@"),)
        ).fetchone()


# ─────────────────────────────────────────────────────────────
# الحظر وفك الحظر
# ─────────────────────────────────────────────────────────────

def is_user_banned(user_id: int) -> bool:
    """التحقق من أن المستخدم محظور."""
    with get_connection() as conn:
        row = conn.execute(
            "SELECT banned FROM users WHERE user_id = ?", (user_id,)
        ).fetchone()
        return bool(row and row["banned"])


def ban_user(user_id: int) -> bool:
    """حظر مستخدم. يُعيد True إذا كان موجوداً."""
    with get_connection() as conn:
        affected = conn.execute(
            "UPDATE users SET banned = 1 WHERE user_id = ?", (user_id,)
        ).rowcount
    logger.info(f"حظر المستخدم {user_id}: {'نجح' if affected else 'غير موجود'}")
    return affected > 0


def unban_user(user_id: int) -> bool:
    """فك حظر مستخدم. يُعيد True إذا كان موجوداً."""
    with get_connection() as conn:
        affected = conn.execute(
            "UPDATE users SET banned = 0 WHERE user_id = ?", (user_id,)
        ).rowcount
    logger.info(f"فك حظر المستخدم {user_id}: {'نجح' if affected else 'غير موجود'}")
    return affected > 0


def get_banned_users() -> list[sqlite3.Row]:
    """جلب قائمة جميع المستخدمين المحظورين."""
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM users WHERE banned = 1 ORDER BY last_active DESC"
        ).fetchall()
