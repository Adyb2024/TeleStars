# ════════════════════════════════════════════════════════════════
#  keyboards.py  —  جميع InlineKeyboardMarkup المستخدمة في البوت
# ════════════════════════════════════════════════════════════════

from telegram import InlineKeyboardButton, InlineKeyboardMarkup


# ─────────────────────────────────────────────────────────────
# القائمة الرئيسية
# ─────────────────────────────────────────────────────────────

def main_menu_keyboard(is_admin: bool = False) -> InlineKeyboardMarkup:
    """القائمة الرئيسية للمستخدم، مع زر لوحة التحكم للمسؤولين."""
    buttons = [
        [InlineKeyboardButton("💰 بيع النجوم",          callback_data="sell_stars")],
        [InlineKeyboardButton("📊 رصيدي وإحصائياتي",    callback_data="my_stats")],
        [InlineKeyboardButton("🧾 سجل المعاملات",        callback_data="tx_history:0")],
        [InlineKeyboardButton("🛡️ الدعم والمساعدة",      callback_data="support")],
    ]
    if is_admin:
        buttons.append(
            [InlineKeyboardButton("⚙️ لوحة التحكم", callback_data="admin_panel")]
        )
    return InlineKeyboardMarkup(buttons)


# ─────────────────────────────────────────────────────────────
# أزرار تدفق البيع
# ─────────────────────────────────────────────────────────────

def cancel_keyboard() -> InlineKeyboardMarkup:
    """زر إلغاء مفرد."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("❌ إلغاء", callback_data="cancel")]
    ])


def wallet_input_keyboard(has_default: bool = False) -> InlineKeyboardMarkup:
    """لوحة إدخال المحفظة: زر المحفظة الافتراضية (إن وُجدت) + إلغاء."""
    buttons: list[list[InlineKeyboardButton]] = []
    if has_default:
        buttons.append([
            InlineKeyboardButton(
                "✅ استخدام محفظتي الافتراضية",
                callback_data="use_default_wallet"
            )
        ])
    buttons.append([InlineKeyboardButton("❌ إلغاء", callback_data="cancel")])
    return InlineKeyboardMarkup(buttons)


def confirm_order_keyboard() -> InlineKeyboardMarkup:
    """أزرار تأكيد أو إلغاء الطلب."""
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ تأكيد ومتابعة", callback_data="confirm_order"),
            InlineKeyboardButton("❌ إلغاء",          callback_data="cancel"),
        ]
    ])


def back_to_main_keyboard() -> InlineKeyboardMarkup:
    """زر العودة للقائمة الرئيسية."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🏠 العودة للقائمة الرئيسية", callback_data="main_menu")]
    ])


# ─────────────────────────────────────────────────────────────
# لوحات المسؤول
# ─────────────────────────────────────────────────────────────

def admin_panel_keyboard() -> InlineKeyboardMarkup:
    """لوحة التحكم الرئيسية للمسؤول."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 إحصائيات فورية",       callback_data="admin_stats")],
        [InlineKeyboardButton("🔄 تبديل حالة البوت",     callback_data="admin_toggle")],
        [InlineKeyboardButton("🔍 آخر 10 معاملات",       callback_data="admin_recent_tx")],
        [InlineKeyboardButton("📝 بث رسالة للجميع",      callback_data="admin_broadcast")],
        [InlineKeyboardButton("🏠 الرئيسية",             callback_data="main_menu")],
    ])


def admin_stats_keyboard() -> InlineKeyboardMarkup:
    """أزرار صفحة الإحصائيات."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 تحديث",  callback_data="admin_stats")],
        [InlineKeyboardButton("◀️ رجوع",   callback_data="admin_panel")],
    ])


def admin_recent_tx_keyboard() -> InlineKeyboardMarkup:
    """أزرار صفحة المعاملات الأخيرة."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 تحديث",  callback_data="admin_recent_tx")],
        [InlineKeyboardButton("◀️ رجوع",   callback_data="admin_panel")],
    ])


def retry_transfer_keyboard(unique_id: str) -> InlineKeyboardMarkup:
    """زر إعادة محاولة تحويل TON (للمسؤول فقط)."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(
            "🔄 إعادة محاولة التحويل",
            callback_data=f"admin_retry:{unique_id}"
        )]
    ])


def broadcast_cancel_keyboard() -> InlineKeyboardMarkup:
    """زر إلغاء عملية البث."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("❌ إلغاء البث", callback_data="cancel_broadcast")]
    ])


# ─────────────────────────────────────────────────────────────
# ترقيم صفحات سجل المعاملات
# ─────────────────────────────────────────────────────────────

def pagination_keyboard(page: int, total_pages: int) -> InlineKeyboardMarkup:
    """
    لوحة تنقل بين صفحات سجل المعاملات.
    تعرض أزرار السابق/التالي حسب الموضع الحالي.
    """
    nav: list[InlineKeyboardButton] = []

    if page > 0:
        nav.append(InlineKeyboardButton("◀️ السابق", callback_data=f"tx_history:{page - 1}"))

    nav.append(InlineKeyboardButton(
        f"📄 {page + 1} / {total_pages}",
        callback_data=f"tx_page_info"  # زر معلومات غير قابل للنقر فعلياً
    ))

    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("التالي ▶️", callback_data=f"tx_history:{page + 1}"))

    buttons = [nav] if nav else []
    buttons.append([InlineKeyboardButton("🔄 تحديث",   callback_data=f"tx_history:{page}")])
    buttons.append([InlineKeyboardButton("🏠 الرئيسية", callback_data="main_menu")])

    return InlineKeyboardMarkup(buttons)


# ═══════════════════════════════════════════════════════════════
#  إضافات v2 — لوحة التحكم الإدارية المتقدمة
# ═══════════════════════════════════════════════════════════════

def admin_panel_v2_keyboard() -> InlineKeyboardMarkup:
    """لوحة التحكم الإدارية الشاملة (النسخة الثانية)."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 لوحة معلومات سريعة",   callback_data="adm_dashboard")],
        [InlineKeyboardButton("📋 معاملات اليوم",         callback_data="adm_today_tx:0")],
        [InlineKeyboardButton("🔍 بحث عن معاملة",         callback_data="adm_search")],
        [InlineKeyboardButton("📈 التقارير",               callback_data="adm_reports_menu")],
        [
            InlineKeyboardButton("⏸️ تبديل البوت",        callback_data="admin_toggle"),
            InlineKeyboardButton("📝 بث رسالة",            callback_data="admin_broadcast"),
        ],
        [InlineKeyboardButton("👥 إدارة المستخدمين",      callback_data="adm_user_mgmt")],
        [InlineKeyboardButton("🛠 إعدادات متقدمة",         callback_data="adm_settings")],
        [InlineKeyboardButton("🏠 الرئيسية",               callback_data="main_menu")],
    ])


def admin_today_tx_keyboard(page: int, total_pages: int) -> InlineKeyboardMarkup:
    """ترقيم صفحات معاملات اليوم في لوحة المسؤول."""
    nav: list[InlineKeyboardButton] = []

    if page > 0:
        nav.append(InlineKeyboardButton("◀️ السابق", callback_data=f"adm_today_tx:{page - 1}"))

    nav.append(InlineKeyboardButton(
        f"📄 {page + 1} / {max(total_pages, 1)}",
        callback_data="adm_noop"
    ))

    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("التالي ▶️", callback_data=f"adm_today_tx:{page + 1}"))

    buttons = [nav] if nav else []
    buttons.append([
        InlineKeyboardButton("🔄 تحديث", callback_data=f"adm_today_tx:{page}"),
        InlineKeyboardButton("◀️ رجوع",  callback_data="admin_panel"),
    ])
    return InlineKeyboardMarkup(buttons)


def admin_reports_keyboard() -> InlineKeyboardMarkup:
    """قائمة خيارات التقارير."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📅 تقرير يومي (24 ساعة)",    callback_data="adm_report:1")],
        [InlineKeyboardButton("📆 تقرير أسبوعي (7 أيام)",   callback_data="adm_report:7")],
        [InlineKeyboardButton("📆 أسبوعان (14 يوماً)",      callback_data="adm_report:14")],
        [InlineKeyboardButton("🗓 تقرير شهري (30 يوماً)",   callback_data="adm_report:30")],
        [InlineKeyboardButton("◀️ رجوع للوحة التحكم",       callback_data="admin_panel")],
    ])


def admin_report_actions_keyboard(days: int) -> InlineKeyboardMarkup:
    """أزرار أسفل التقرير: تصدير CSV + رجوع."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"📤 تصدير CSV ({days} يوم)", callback_data=f"adm_export_csv:{days}")],
        [InlineKeyboardButton("◀️ رجوع للتقارير",           callback_data="adm_reports_menu")],
    ])


def admin_user_mgmt_keyboard() -> InlineKeyboardMarkup:
    """قائمة إدارة المستخدمين."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🚫 حظر مستخدم",        callback_data="adm_ban_entry")],
        [InlineKeyboardButton("✅ فك حظر مستخدم",     callback_data="adm_unban_entry")],
        [InlineKeyboardButton("📋 عرض المحظورين",      callback_data="adm_banned_list")],
        [InlineKeyboardButton("◀️ رجوع",               callback_data="admin_panel")],
    ])


def admin_settings_keyboard() -> InlineKeyboardMarkup:
    """قائمة الإعدادات المتقدمة."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💵 سعر البيع التقديري",         callback_data="adm_set_sell_price")],
        [InlineKeyboardButton("📢 قناة الإشعارات",             callback_data="adm_set_channel")],
        [InlineKeyboardButton("⭐ الحد الأدنى للنجوم",         callback_data="adm_set_min_stars")],
        [InlineKeyboardButton("⚠️ حد منخفض رصيد TON",         callback_data="adm_set_low_bal")],
        [InlineKeyboardButton("📅 تقرير يومي تلقائي",          callback_data="adm_toggle_daily_report")],
        [InlineKeyboardButton("◀️ رجوع",                       callback_data="admin_panel")],
    ])


def admin_cancel_conv_keyboard() -> InlineKeyboardMarkup:
    """زر إلغاء داخل محادثات المسؤول."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("❌ إلغاء", callback_data="adm_cancel_conv")]
    ])
