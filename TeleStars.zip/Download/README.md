# 🌟 Stars Buyer Bot — بوت شراء نجوم تيليجرام

بوت احترافي لشراء نجوم تيليجرام (Telegram Stars) من المستخدمين مباشرةً، ودفع المقابل بعملة **TON** تلقائياً.

---

## 📁 هيكل الملفات

```
star_bot/
├── main.py           # نقطة الدخول + جميع Handlers
├── config.py         # الإعدادات (يجب تعديله قبل التشغيل)
├── db.py             # طبقة SQLite
├── ton_utils.py      # سعر TON، التحقق من العناوين، إرسال TON
├── keyboards.py      # جميع InlineKeyboardMarkup
├── requirements.txt  # المكتبات
└── README.md
```

---

## ⚙️ الإعداد خطوة بخطوة

### 1. الحصول على BOT_TOKEN

1. افتح تيليجرام وابحث عن **@BotFather**
2. أرسل `/newbot` واتبع التعليمات
3. انسخ الـ Token وضعه في `config.py` ← `BOT_TOKEN`

> **مهم:** لقبول مدفوعات النجوم، أرسل لـ BotFather: `/mybots` → اختر البوت → *Bot Settings* → *Payments* → **Telegram Stars**

---

### 2. الحصول على TONCENTER_API_KEY

1. افتح [@tonapibot](https://t.me/tonapibot) على تيليجرام
2. أرسل `/auth` للحصول على مفتاحك المجاني
3. ضعه في `config.py` ← `TONCENTER_API_KEY`

---

### 3. إعداد محفظة TON للبوت

البوت يحتاج محفظة TON خاصة به لإرسال مدفوعات للمستخدمين.

**الطريقة الموصى بها (Tonkeeper):**
1. حمّل [Tonkeeper](https://tonkeeper.com) أو أي محفظة TON
2. أنشئ محفظة جديدة مخصصة للبوت فقط
3. احتفظ بعبارة الاسترداد (24 كلمة) بأمان تام
4. ضعها في `config.py` ← `MNEMONIC` مفصولةً بمسافات:
   ```python
   MNEMONIC = "word1 word2 word3 ... word24"
   ```
5. **أودع كمية كافية من TON** في هذه المحفظة لتغطية المدفوعات

> ⚠️ **تحذير أمني:** لا تشارك MNEMONIC مع أي شخص. من يملكها يتحكم في المحفظة كاملاً.

---

### 4. تحديد المسؤولين

للحصول على معرفك الرقمي على تيليجرام:
- افتح [@userinfobot](https://t.me/userinfobot) وأرسل `/start`
- انسخ الرقم وأضفه لـ `config.py` ← `ADMIN_USER_IDS`:
  ```python
  ADMIN_USER_IDS = [123456789, 987654321]  # يمكن إضافة عدة مسؤولين
  ```

---

### 5. تثبيت المكتبات

```bash
cd star_bot
pip install -r requirements.txt
```

---

### 6. التشغيل

```bash
python main.py
```

عند التشغيل الأول، يُنشئ البوت تلقائياً ملف `star_bot.db` (قاعدة البيانات).

---

## 🚀 النشر على PythonAnywhere

### الخطوات:

1. **افتح حساباً** على [pythonanywhere.com](https://www.pythonanywhere.com) (الخطة المجانية كافية للبداية)

2. **رفع الملفات** عبر Files → Upload:
   - ارفع جميع ملفات `star_bot/` إلى مجلد مثل `/home/yourusername/star_bot/`

3. **فتح Bash Console** وتثبيت المكتبات:
   ```bash
   cd star_bot
   pip3.10 install --user -r requirements.txt
   ```

4. **تعديل config.py** بالقيم الحقيقية مباشرةً من الـ Bash Console:
   ```bash
   nano config.py
   ```

5. **تشغيل البوت** كـ Always-on Task (يتطلب خطة مدفوعة) أو من الـ Console:
   ```bash
   python3.10 main.py
   ```

   **للتشغيل المستمر بدون Always-on (الحل المجاني):**
   ```bash
   nohup python3.10 main.py &
   ```
   > ملاحظة: الحسابات المجانية على PythonAnywhere تنتهي جلساتها بعد 24 ساعة. للتشغيل الدائم، استخدم خطة مدفوعة أو VPS.

---

## 🔄 آلية عمل البوت

```
المستخدم يضغط "بيع النجوم"
        ↓
يُدخل عدد النجوم (≥ 50)
        ↓
يُدخل عنوان محفظة TON
        ↓
يرى ملخص الطلب ويؤكد
        ↓
البوت ينشئ فاتورة Telegram Stars (XTR)
        ↓
المستخدم يدفع الفاتورة → تنتقل النجوم للبوت
        ↓
البوت يُحوّل TON تلقائياً إلى محفظة المستخدم
        ↓
إشعار بالاكتمال ✅
```

---

## 💰 التسعير

| العملة | الحساب |
|--------|--------|
| سعر الشراء | `1.12 USD` لكل 100 نجمة |
| مثال: 500 نجمة | `5.60 USD` ÷ سعر TON الحالي |
| سعر TON | يُحدَّث تلقائياً كل 5 دقائق من CoinGecko |

---

## 🛡️ أنظمة الأمان

| النظام | التفاصيل |
|--------|----------|
| Rate Limiting | منع إرسال طلبين خلال 3 ثوانٍ |
| تحقق المبلغ | مطابقة صارمة في `pre_checkout_query` |
| مهلة الجلسة | إلغاء تلقائي بعد 5 دقائق خمول |
| تحقق المحفظة | Regex يقبل الصيغتين الودية والخام |
| UUID فريد | كل معاملة لها `unique_id` يمنع التكرار |
| إشعار المسؤول | تنبيه فوري عند فشل تحويل TON |

---

## ⚙️ لوحة التحكم `/admin`

متاحة فقط للمعرفات في `ADMIN_USER_IDS`:

- **📊 إحصائيات فورية** — رصيد TON، عدد المعاملات، إجمالي النجوم
- **🔄 تبديل حالة البوت** — إيقاف/تشغيل الخدمة بزر واحد
- **🔍 آخر 10 معاملات** — مع حالة كل منها
- **📝 بث رسالة** — إرسال إعلان لجميع المستخدمين
- **🔄 إعادة محاولة التحويل** — عند فشل تحويل TON

---

## 🗄️ قاعدة البيانات (SQLite)

### جدول `users`
| العمود | النوع | الوصف |
|--------|-------|-------|
| user_id | INTEGER PK | معرف تيليجرام |
| username | TEXT | اسم المستخدم |
| first_name | TEXT | الاسم الأول |
| wallet_address | TEXT | المحفظة الافتراضية |
| total_stars_sold | INTEGER | إجمالي النجوم المبيعة |
| total_ton_received | REAL | إجمالي TON المستلمة |
| created_at / last_active | TEXT | تواريخ |

### جدول `transactions`
| العمود | النوع | الوصف |
|--------|-------|-------|
| unique_id | TEXT UNIQUE | المعرف الفريد للمعاملة |
| user_id | INTEGER FK | صاحب المعاملة |
| star_count | INTEGER | عدد النجوم |
| ton_amount | REAL | المبلغ بـ TON |
| usd_amount | REAL | المبلغ بالدولار |
| wallet_address | TEXT | محفظة الاستلام |
| status | TEXT | `pending` → `invoice_sent` → `paid` → `completed` / `failed` |
| invoice_payload | TEXT | payload الفاتورة (= unique_id) |
| ton_tx_hash | TEXT | مرجع التحويل على شبكة TON |
| error_message | TEXT | رسالة الخطأ عند الفشل |

---

## 🐛 استكشاف الأخطاء

| المشكلة | الحل |
|---------|------|
| `Unauthorized` عند التشغيل | تحقق من `BOT_TOKEN` في `config.py` |
| `RuntimeError: TON Center رفض` | تحقق من `TONCENTER_API_KEY` وصحة `MNEMONIC` |
| فاتورة لا تظهر | تأكد من تفعيل Telegram Stars في @BotFather |
| التحويل يفشل دائماً | تأكد من وجود رصيد TON كافٍ في محفظة البوت |
| سعر TON = 0 | تحقق من اتصال الإنترنت، أو انتظر تحديث الـ Job |

---

## 📄 الترخيص

للاستخدام الشخصي والتجاري. المطور مسؤول عن الامتثال لقوانين منطقته.
