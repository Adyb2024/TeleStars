# ════════════════════════════════════════════════════════════════
#  config.py  —  إعدادات بوت نجوم تيليجرام
#  عدّل هذا الملف قبل التشغيل
# ════════════════════════════════════════════════════════════════

# ── Telegram ──────────────────────────────────────────────────
BOT_TOKEN: str = "YOUR_BOT_TOKEN_HERE"

# ── TON Center ────────────────────────────────────────────────
TONCENTER_API_KEY: str = "YOUR_TONCENTER_API_KEY_HERE"
TON_CENTER_URL: str = "https://toncenter.com/api/v2"

# ── المحفظة الرئيسية للبوت (24 كلمة مفصولة بمسافات) ──────────
MNEMONIC: str = (
    "word1 word2 word3 word4 word5 word6 "
    "word7 word8 word9 word10 word11 word12 "
    "word13 word14 word15 word16 word17 word18 "
    "word19 word20 word21 word22 word23 word24"
)

# ── المسؤولون ─────────────────────────────────────────────────
# أضف معرفاتك الرقمية على تيليجرام (يمكن الحصول عليها من @userinfobot)
ADMIN_USER_IDS: list[int] = [123456789]

# ── التسعير ───────────────────────────────────────────────────
PRICE_PER_100_STARS_USD: float = 1.12   # سعر الشراء لكل 100 نجمة بالدولار
MIN_STARS: int = 50                      # الحد الأدنى للنجوم في صفقة واحدة
MAX_STARS: int = 500_000                 # الحد الأقصى للنجوم في صفقة واحدة

# ── CoinGecko (سعر TON/USD) ───────────────────────────────────
COINGECKO_URL: str = (
    "https://api.coingecko.com/api/v3/simple/price"
    "?ids=the-open-network&vs_currencies=usd"
)
PRICE_UPDATE_INTERVAL: int = 300        # تحديث السعر كل 5 دقائق (ثوانٍ)

# ── قاعدة البيانات ────────────────────────────────────────────
DB_PATH: str = "star_bot.db"

# ── حدود الأمان ───────────────────────────────────────────────
RATE_LIMIT_SECONDS: int = 3             # الحد الأدنى بين الطلبات لكل مستخدم
CONVERSATION_TIMEOUT: int = 300         # مهلة انتهاء المحادثة (5 دقائق)

# ── رسالة الدعم ───────────────────────────────────────────────
SUPPORT_USERNAME: str = "@YourSupportUsername"

# ── قناة سجل المعاملات ────────────────────────────────────────
# معرف القناة بـ @ (مثال: "@MyLogChannel") أو ID رقمي (مثال: -1001234567890)
# يجب أن يكون البوت مشرفاً في القناة مع صلاحية "نشر الرسائل"
# اتركه فارغاً ("") لتعطيل إشعارات القناة
NOTIFICATION_CHANNEL: str = "@YourLogChannel"
