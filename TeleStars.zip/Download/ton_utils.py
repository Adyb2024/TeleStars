# ════════════════════════════════════════════════════════════════
#  ton_utils.py  —  أدوات TON: السعر، التحقق، الإرسال
# ════════════════════════════════════════════════════════════════

import re
import hashlib
import base64
import logging
import requests
from typing import Optional

import config

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────
# التحقق من عناوين TON
# ─────────────────────────────────────────────────────────────

# الصيغة الودية (base64url, 48 حرفاً)  |  الصيغة الخام (0:hex64)
_TON_FRIENDLY_RE = re.compile(r'^[0-9a-zA-Z_+/\-]{48}$')
_TON_RAW_RE      = re.compile(r'^0:[0-9a-fA-F]{64}$')


def validate_ton_address(address: str) -> bool:
    """
    التحقق من صحة عنوان محفظة TON.
    يقبل الصيغة الودية (EQ.../UQ...) والصيغة الخام (0:...).
    """
    address = address.strip()
    return bool(_TON_FRIENDLY_RE.match(address) or _TON_RAW_RE.match(address))


# ─────────────────────────────────────────────────────────────
# سعر TON/USD
# ─────────────────────────────────────────────────────────────

def get_ton_price_usd() -> float:
    """
    جلب سعر TON بالدولار من CoinGecko API.
    يرفع استثناءً عند الفشل.
    """
    try:
        resp = requests.get(config.COINGECKO_URL, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        price = float(data["the-open-network"]["usd"])
        if price <= 0:
            raise ValueError(f"سعر TON غير منطقي: {price}")
        logger.info(f"سعر TON المحدَّث: ${price:.4f}")
        return price
    except requests.RequestException as exc:
        logger.error(f"فشل الاتصال بـ CoinGecko: {exc}")
        raise RuntimeError("تعذّر جلب سعر TON من CoinGecko.") from exc
    except (KeyError, ValueError) as exc:
        logger.error(f"خطأ في تحليل استجابة CoinGecko: {exc}")
        raise RuntimeError("استجابة CoinGecko غير متوقعة.") from exc


def calculate_ton_amount(star_count: int, ton_usd_price: float) -> tuple[float, float]:
    """
    حساب المبلغ بـ TON مقابل عدد النجوم المحدد.
    يُعيد (ton_amount, usd_amount) مقرَّبَين.
    """
    if ton_usd_price <= 0:
        raise ValueError("سعر TON يجب أن يكون أكبر من صفر.")
    usd_amount  = (star_count / 100.0) * config.PRICE_PER_100_STARS_USD
    ton_amount  = usd_amount / ton_usd_price
    return round(ton_amount, 6), round(usd_amount, 4)


# ─────────────────────────────────────────────────────────────
# عمليات TON Center API
# ─────────────────────────────────────────────────────────────

def _toncenter_get(endpoint: str, params: Optional[dict] = None) -> dict:
    """طلب GET مصدَّق إلى TON Center API."""
    resp = requests.get(
        f"{config.TON_CENTER_URL}/{endpoint}",
        params=params,
        headers={"X-API-Key": config.TONCENTER_API_KEY},
        timeout=15
    )
    resp.raise_for_status()
    data = resp.json()
    if not data.get("ok"):
        raise RuntimeError(f"TON Center رفض الطلب: {data.get('error', 'خطأ غير معروف')}")
    return data["result"]


def _toncenter_post(endpoint: str, payload: dict) -> dict:
    """طلب POST مصدَّق إلى TON Center API."""
    resp = requests.post(
        f"{config.TON_CENTER_URL}/{endpoint}",
        headers={
            "X-API-Key": config.TONCENTER_API_KEY,
            "Content-Type": "application/json"
        },
        json=payload,
        timeout=30
    )
    resp.raise_for_status()
    data = resp.json()
    if not data.get("ok"):
        raise RuntimeError(f"TON Center رفض العملية: {data.get('error', 'خطأ غير معروف')}")
    return data.get("result", {})


def _get_bot_wallet():
    """
    إنشاء محفظة البوت من MNEMONIC.
    يُعيد (wallet_contract, address_string).
    """
    from tonsdk.contract.wallet import WalletVersionEnum, Wallets

    mnemonics = config.MNEMONIC.split()
    if len(mnemonics) < 12:
        raise ValueError("MNEMONIC يجب أن يحتوي على 12 كلمة على الأقل.")

    _m, _pub, _priv, wallet = Wallets.from_mnemonics(
        mnemonics, WalletVersionEnum.v4r2, workchain=0
    )
    address_str = wallet.address.to_string(
        is_user_friendly=True,
        is_url_safe=True,
        is_bounceable=True
    )
    return wallet, address_str


def get_bot_ton_balance() -> float:
    """
    جلب رصيد TON لمحفظة البوت عبر TON Center API.
    يُعيد الرصيد بوحدة TON.
    """
    try:
        _, address = _get_bot_wallet()
        result = _toncenter_get("getAddressInformation", {"address": address})
        balance_nano = int(result.get("balance", 0))
        return balance_nano / 1_000_000_000  # nanoTON → TON
    except Exception as exc:
        logger.error(f"فشل جلب رصيد TON: {exc}")
        raise


def get_bot_wallet_address() -> str:
    """إعادة عنوان محفظة البوت الودي."""
    _, address = _get_bot_wallet()
    return address


def _get_seqno(address: str) -> int:
    """
    جلب رقم التسلسل (seqno) لمحفظة عبر runGetMethod.
    يُعيد 0 للمحفظة غير المهيأة بعد.
    """
    try:
        result = _toncenter_post(
            "runGetMethod",
            {"address": address, "method": "seqno", "stack": []}
        )
        stack = result.get("stack", [])
        if not stack:
            return 0
        raw_val = stack[0][1]
        if isinstance(raw_val, str) and raw_val.startswith("0x"):
            return int(raw_val, 16)
        return int(raw_val)
    except Exception as exc:
        logger.warning(f"تعذّر جلب seqno ({address[:16]}...): {exc} — سيتم استخدام 0")
        return 0


def send_ton(to_address: str, amount_ton: float, comment: str = "") -> str:
    """
    إرسال TON من محفظة البوت إلى عنوان المستخدم.
    يُعيد مرجع المعاملة (hash مشتق من BOC).
    يرفع استثناءً عند فشل الإرسال.
    """
    from tonsdk.contract.wallet import WalletVersionEnum, Wallets
    from tonsdk.utils import to_nano, bytes_to_b64str

    try:
        # إنشاء المحفظة من MNEMONIC
        mnemonics = config.MNEMONIC.split()
        _m, _pub, _priv, wallet = Wallets.from_mnemonics(
            mnemonics, WalletVersionEnum.v4r2, workchain=0
        )
        address_str = wallet.address.to_string(True, True, True)

        # جلب seqno
        seqno = _get_seqno(address_str)
        logger.info(f"Seqno الحالي للمحفظة: {seqno}")

        # تحويل TON إلى nanoTON
        amount_nano = to_nano(amount_ton, "ton")

        # بناء رسالة التحويل
        transfer = wallet.create_transfer_message(
            to_addr=to_address.strip(),
            amount=amount_nano,
            seqno=seqno,
            payload=comment[:120] if comment else ""
        )

        # تحويل الخلية إلى BOC ثم Base64
        boc_bytes = transfer["message"].to_boc(False)
        boc_b64   = bytes_to_b64str(boc_bytes)

        # إرسال BOC عبر TON Center
        _toncenter_post("sendBoc", {"boc": boc_b64})

        # حساب hash مرجعي من BOC
        boc_hash = base64.urlsafe_b64encode(
            hashlib.sha256(boc_bytes).digest()
        ).decode()[:20]

        logger.info(
            f"تحويل TON ناجح: {amount_ton:.6f} TON → {to_address[:16]}... "
            f"| ref: {boc_hash}"
        )
        return boc_hash

    except RuntimeError:
        raise  # إعادة رفع أخطاء TON Center كما هي
    except Exception as exc:
        logger.error(f"خطأ غير متوقع في send_ton: {exc}", exc_info=True)
        raise RuntimeError(f"فشل إرسال TON: {exc}") from exc
