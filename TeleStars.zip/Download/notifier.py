# ════════════════════════════════════════════════════════════════
#  notifier.py  —  نظام إشعارات القناة التفصيلية
#  يُرسل إشعاراً فورياً لقناة تيليجرام بعد كل معاملة
# ════════════════════════════════════════════════════════════════

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any

from telegram.constants import ParseMode
from telegram.error import TelegramError
from telegram.ext import ContextTypes

import config

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────
# دوال مساعدة داخلية
# ─────────────────────────────────────────────────────────────

def _format_username(username: str | None, first_name: str | None = None) -> str:
    """
    تنسيق اسم المستخدم للعرض:
    · إذا كان لديه @username → يُعاد @username
    · إذا لم يكن → يُعاد الاسم الأول مع تنبيه "(لا يوجد معرف)"
    """
    if username:
        return f"@{username.lstrip('@')}"
    display = first_name or "مستخدم مجهول"
    return f"{display} <i>(لا يوجد معرف)</i>"


def _now_formatted() -> str:
    """إعادة التوقيت الحالي UTC بتنسيق قابل للقراءة."""
    return datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


async def _send_to_channel(context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    """
    إرسال رسالة للقناة المحددة في config.NOTIFICATION_CHANNEL.
    تُعالَج جميع الأخطاء داخلياً ولا تُوقف العملية الرئيسية أبداً.
    """
    channel = getattr(config, "NOTIFICATION_CHANNEL", None)
    if not channel:
        logger.debug("NOTIFICATION_CHANNEL غير مضبوط — تم تخطي الإشعار.")
        return

    try:
        await context.bot.send_message(
            chat_id=channel,
            text=text,
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True,
        )
        logger.debug(f"إشعار أُرسل إلى القناة {channel}")
    except TelegramError as exc:
        logger.error(
            f"فشل إرسال الإشعار إلى القناة {channel}: {exc} — "
            "تحقق من أن البوت مشرف في القناة وأن المعرف صحيح."
        )
    except Exception as exc:
        logger.error(f"خطأ غير متوقع في _send_to_channel: {exc}", exc_info=True)


# ─────────────────────────────────────────────────────────────
# الدوال العامة
# ─────────────────────────────────────────────────────────────

async def notify_success(
    context: ContextTypes.DEFAULT_TYPE,
    transaction_data: dict[str, Any],
) -> None:
    """
    إشعار قناة السجل بنجاح المعاملة وإتمام تحويل TON.

    transaction_data يجب أن يحتوي على:
        uuid, user_id, username, first_name, star_amount,
        usd_value, ton_price, ton_amount, wallet_address,
        tx_hash, timestamp (اختياري)
    """
    username_display = _format_username(
        transaction_data.get("username"),
        transaction_data.get("first_name"),
    )
    timestamp = transaction_data.get("timestamp") or _now_formatted()

    text = (
        "✅ <b>عملية مكتملة</b>\n"
        "━━━━━━━━━━━━━━━━━\n"
        f"🆔 <b>معرف المعاملة:</b> <code>{transaction_data.get('uuid', 'N/A')}</code>\n"
        f"👤 <b>المستخدم:</b> {username_display} (ID: <code>{transaction_data.get('user_id', '?')}</code>)\n"
        f"⭐ <b>عدد النجوم:</b> {transaction_data.get('star_amount', 0):,} ⭐\n"
        f"💵 <b>القيمة بالدولار:</b> ${transaction_data.get('usd_value', 0):.4f}\n"
        f"💎 <b>سعر TON/USD:</b> ${transaction_data.get('ton_price', 0):.4f}\n"
        f"💰 <b>المبلغ المحوَّل:</b> {transaction_data.get('ton_amount', 0):.6f} TON\n"
        f"🔗 <b>معرف التحويل:</b> <code>{transaction_data.get('tx_hash', 'N/A')}</code>\n"
        f"🏦 <b>عنوان المحفظة:</b> <code>{transaction_data.get('wallet_address', 'N/A')}</code>\n"
        f"📅 <b>التاريخ والوقت:</b> {timestamp}\n"
        "━━━━━━━━━━━━━━━━━\n"
        "🟢 <b>الحالة: ناجحة</b>"
    )

    # إطلاق الإرسال كـ Task مستقل لا يُعيق الاستجابة للمستخدم
    asyncio.ensure_future(_send_to_channel(context, text))
    logger.info(f"إشعار نجاح مُجدوَل للمعاملة {transaction_data.get('uuid')}")


async def notify_failure(
    context: ContextTypes.DEFAULT_TYPE,
    transaction_data: dict[str, Any],
    error_message: str,
) -> None:
    """
    إشعار قناة السجل بفشل المعاملة مع سبب الفشل.

    transaction_data يجب أن يحتوي على:
        uuid, user_id, username, first_name, star_amount,
        timestamp (اختياري)
    """
    username_display = _format_username(
        transaction_data.get("username"),
        transaction_data.get("first_name"),
    )
    timestamp     = transaction_data.get("timestamp") or _now_formatted()
    safe_error    = str(error_message)[:400]  # تقليص الرسالة لتجنب تجاوز حد تيليجرام

    text = (
        "❌ <b>عملية فاشلة</b>\n"
        "━━━━━━━━━━━━━━━━━\n"
        f"🆔 <b>معرف المعاملة:</b> <code>{transaction_data.get('uuid', 'N/A')}</code>\n"
        f"👤 <b>المستخدم:</b> {username_display} (ID: <code>{transaction_data.get('user_id', '?')}</code>)\n"
        f"⭐ <b>عدد النجوم:</b> {transaction_data.get('star_amount', 0):,}\n"
        f"📅 <b>التاريخ والوقت:</b> {timestamp}\n"
        f"📛 <b>سبب الفشل:</b> <code>{safe_error}</code>\n"
        "━━━━━━━━━━━━━━━━━\n"
        "🔴 <b>الحالة: فشلت</b>"
    )

    asyncio.ensure_future(_send_to_channel(context, text))
    logger.info(f"إشعار فشل مُجدوَل للمعاملة {transaction_data.get('uuid')}")
